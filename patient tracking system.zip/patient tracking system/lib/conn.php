<?php
//connection
//server
//username
//password
//database
$conn=new mysqli("localhost","root","","ohms");
?>
