 <div class="pcoded-main-container">
        <div class="pcoded-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5 class="m-b-10">Hospital Dashboard</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="#!">Hospital</a></li>
                                <li class="breadcrumb-item"><a href="#!">Dashboard</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div><?php
                                include 'lib/conn.php';
                                $sql = "select count(id) dc from doctors";
                                $res = $conn->query($sql);
                                $row = $res->fetch_assoc();
                                ?>
            <!-- [ breadcrumb ] end -->
            <!-- [ Main Content ] start -->
            <div class="center-content">
            <div class="row">
                <!-- customar project  start -->
                <div class="col-xl-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center m-l-0">
                                <div class="col-auto">
                                    <i class="fas fa-user-md f-36 text-c-purple"></i>
                                </div>
                                <div class="col-auto">
                                    <h6 class="text-muted m-b-10">Doctor</h6>
                                    <h2 class="m-b-0"><?php echo $row['dc'];  ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                                include 'lib/conn.php';
                                $sql = "select count(id) pt from patients";
                                $res = $conn->query($sql);
                                $row = $res->fetch_assoc();
                                ?>
                <div class="col-xl-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center m-l-0">
                                <div class="col-auto">
                                    <i class="fas fa-user-injured f-36 text-c-red"></i>
                                </div>
                                <div class="col-auto">
                                    <h6 class="text-muted m-b-10">Patient</h6>
                                    <h2 class="m-b-0"><?php echo $row['pt'];  ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                                include 'lib/conn.php';
                                $sql = "select count(id) nr from nurses";
                                $res = $conn->query($sql);
                                $row = $res->fetch_assoc();
                                ?>
                <div class="col-xl-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center m-l-0">
                                <div class="col-auto">
                                    <i class="fas fa-user-nurse f-36 text-c-green"></i>
                                </div>
                                <div class="col-auto">
                                    <h6 class="text-muted m-b-10">Nurse</h6>
                                    <h2 class="m-b-0"><?php echo $row['nr'];  ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                                include 'lib/conn.php';
                                $sql = "select count(id) ph from pharmacist";
                                $res = $conn->query($sql);
                                $row = $res->fetch_assoc();
                                ?>
                <div class="col-xl-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center m-l-0">
                                <div class="col-auto">
                                    <i class="fas fa-prescription-bottle-alt f-36 text-c-blue"></i>
                                </div>
                                <div class="col-auto">
                                    <h6 class="text-muted m-b-10">Pharmacist</h6>
                                    <h2 class="m-b-0"><?php echo $row['ph'];  ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                                include 'lib/conn.php';
                                $sql = "select count(id) lb from laboratoristreg";
                                $res = $conn->query($sql);
                                $row = $res->fetch_assoc();
                                ?>
                <div class="col-xl-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center m-l-0">
                                <div class="col-auto">
                                    <i class="fas fa-flask f-36 text-c-yellow"></i>
                                </div>
                                <div class="col-auto">
                                    <h6 class="text-muted m-b-10">Laboratories</h6>
                                    <h2 class="m-b-0"><?php echo $row['lb'];  ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php
                                include 'lib/conn.php';
                                $sql = "select count(Deptid) dd from departments";
                                $res = $conn->query($sql);
                                $row = $res->fetch_assoc();
                                ?>
                <div class="col-xl-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center m-l-0">
                                <div class="col-auto">
                                    <i class="fas fa-user-tie f-36 text-c-blue"></i>
                                </div>
                                <div class="col-auto">
                                    <h6 class="text-muted m-b-10">Accountant</h6>
                                    <h2 class="m-b-0"><?php echo $row['dd'];  ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                                include 'lib/conn.php';
                                $sql = "select count(Id) py from payment ";
                                $res = $conn->query($sql);
                                $row = $res->fetch_assoc();
                                ?>
                <div class="col-xl-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center m-l-0">
                                <div class="col-auto">
                                    <i class="fas fa-file-invoice-dollar f-36 text-c-red"></i>
                                </div>
                                <div class="col-auto">
                                    <h6 class="text-muted m-b-10">Payment</h6>
                                    <h2 class="m-b-0"><?php echo $row['py'];  ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row align-items-center m-l-0">
                                <div class="col-auto">
                                    <i class="fas fa-pills f-36 text-c-purple"></i>
                                </div>
                                <div class="col-auto">
                                    <h6 class="text-muted m-b-10">Medicine</h6>
                                    <h2 class="m-b-0">10</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- customar project  end -->
                <!-- subscribe start -->
                <?php
                                include 'lib/conn.php';
                                $sql = "select count(id) ob from operations";
                                $res = $conn->query($sql);
                                $row = $res->fetch_assoc();
                                ?>
                <div class="col-md-12 col-lg-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-procedures text-c-blue d-block f-40"></i>
                            <h4 class="m-t-20 m-b-20"><span class="text-c-blue"><?php echo $row['ob'];  ?></span> Operation</h4>
                            <button class="btn btn-primary btn-sm btn-round" data-bs-toggle="modal" data-title="Operation" data-bs-target="#modal-report">View Report</button>
                        </div>
                        <div id="operation-chart"></div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-skull-crossbones text-c-green d-block f-40"></i>
                            <h4 class="m-t-20 m-b-20"><span class="text-c-green">+40</span> Death</h4>
                            <button class="btn btn-success btn-sm btn-round" data-bs-toggle="modal" data-title="Death" data-bs-target="#modal-report">View Report</button>
                        </div>
                        <div id="death-chart"></div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-baby text-c-red d-block f-40"></i>
                            <h4 class="m-t-20 m-b-20"><span class="text-c-red">+40</span> Birth</h4>
                            <button class="btn btn-danger btn-sm btn-round" data-bs-toggle="modal" data-title="Birth" data-bs-target="#modal-report">View Report</button>
                        </div>
                        <div id="birth-chart"></div>
                    </div>
                </div>
                <!-- subscribe end -->

            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>
   </div> 