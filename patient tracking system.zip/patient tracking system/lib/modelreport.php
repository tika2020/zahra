 <div class="modal fade" id="modal-report" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table id="report-table" class="table table-bordered table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Sex</th>
                                    <th>Birth Date</th>
                                    <th>Age</th>
                                    <th>Blood Group</th>
                                    <th>Options</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><img src="assets/images/user/avatar-1.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Tanvir Hasan</td>
                                    <td>patient@example.com</td>
                                    <td>9876543</td>
                                    <td>female</td>
                                    <td>13/09/1994</td>
                                    <td>54</td>
                                    <td>o+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-2.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Joseph William</td>
                                    <td>Joseph@example.com</td>
                                    <td>1234567</td>
                                    <td>male</td>
                                    <td>09/10/1990</td>
                                    <td>27</td>
                                    <td>B+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-3.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Tanvir Hasan</td>
                                    <td>patient@example.com</td>
                                    <td>9876543</td>
                                    <td>female</td>
                                    <td>13/09/1994</td>
                                    <td>54</td>
                                    <td>o+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-4.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Joseph William</td>
                                    <td>Joseph@example.com</td>
                                    <td>1234567</td>
                                    <td>male</td>
                                    <td>09/10/1990</td>
                                    <td>27</td>
                                    <td>B+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-1.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Tanvir Hasan</td>
                                    <td>patient@example.com</td>
                                    <td>9876543</td>
                                    <td>female</td>
                                    <td>13/09/1994</td>
                                    <td>54</td>
                                    <td>o+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-2.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Joseph William</td>
                                    <td>Joseph@example.com</td>
                                    <td>1234567</td>
                                    <td>male</td>
                                    <td>09/10/1990</td>
                                    <td>27</td>
                                    <td>B+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-3.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Tanvir Hasan</td>
                                    <td>patient@example.com</td>
                                    <td>9876543</td>
                                    <td>female</td>
                                    <td>13/09/1994</td>
                                    <td>54</td>
                                    <td>o+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-4.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Joseph William</td>
                                    <td>Joseph@example.com</td>
                                    <td>1234567</td>
                                    <td>male</td>
                                    <td>09/10/1990</td>
                                    <td>27</td>
                                    <td>B+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-1.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Tanvir Hasan</td>
                                    <td>patient@example.com</td>
                                    <td>9876543</td>
                                    <td>female</td>
                                    <td>13/09/1994</td>
                                    <td>54</td>
                                    <td>o+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-2.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Joseph William</td>
                                    <td>Joseph@example.com</td>
                                    <td>1234567</td>
                                    <td>male</td>
                                    <td>09/10/1990</td>
                                    <td>27</td>
                                    <td>B+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-3.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Tanvir Hasan</td>
                                    <td>patient@example.com</td>
                                    <td>9876543</td>
                                    <td>female</td>
                                    <td>13/09/1994</td>
                                    <td>54</td>
                                    <td>o+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td><img src="assets/images/user/avatar-4.jpg" class="img-radius" width="30px" height="30px"></td>
                                    <td>Joseph William</td>
                                    <td>Joseph@example.com</td>
                                    <td>1234567</td>
                                    <td>male</td>
                                    <td>09/10/1990</td>
                                    <td>27</td>
                                    <td>B+</td>
                                    <td>
                                        <a href="#!" class="btn btn-info btn-sm">Edit</a>
                                        <a href="#!" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>