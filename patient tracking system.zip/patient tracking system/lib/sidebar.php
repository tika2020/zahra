 <nav class="pcoded-navbar menu-light ">
        <div class="navbar-wrapper  ">
            <div class="navbar-content scroll-div ">

                <div class="">
                    <div class="main-menu-header">
                        <img class="img-radius" src="assets/images/user/avatar-4.jpg" alt="User-Profile-Image">
                        <div class="user-details">
                            <div id="more-details">Dr.Libaan Ahmed<i class="fa fa-caret-down"></i></div>
                        </div>
                    </div>
                    <div class="collapse" id="nav-user-link">
                        <ul class="list-inline">
                            <li class="list-inline-item"><a href="user-profile.html" data-toggle="tooltip" title="View Profile"><i class="feather icon-user"></i></a></li>
                            <li class="list-inline-item"><a href="email_inbox.html"><i class="feather icon-mail" data-toggle="tooltip" title="Messages"></i><small class="badge badge-pill badge-primary">5</small></a></li>
                            <li class="list-inline-item"><a href="login.html" data-toggle="tooltip" title="Logout" class="text-danger"><i class="feather icon-power"></i></a></li>
                        </ul>
                    </div>
                </div>

                <ul class="nav pcoded-inner-navbar ">
                    <li class="nav-item pcoded-menu-caption">
                        <label>Navigation</label>
                    </li>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    </li>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="feather icon-user"></i></span><span class="pcoded-mtext">Patient</span></a>
                        <ul class="pcoded-submenu">
                            <li><a href="sys_forms/patient.php" class="sys_links" target="_blank">Patient List</a></li>
                            <li><a href="sys_forms/intake.php" class="sys_links" target="_blank">Patient InTake</a></li>
                            <li><a href="sys_forms/treatment.php" class="sys_links" target="_blank">Patient Treatment</a></li>
                            <li><a href="sys_forms/progress.php" class="sys_links" target="_blank">Progress Note</a></li>
                        </ul>
                    </li>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Doctor</span></a>
                        <ul class="pcoded-submenu">
                            <li><a href="sys_forms/doctor.php" class="sys_links" target="_blank">Doctor List</a></li>
                        </ul>
                    </li>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Nursing</span></a>
                        <ul class="pcoded-submenu">
                            <li><a href="sys_forms/nursing.php" class="sys_links" target="_blank">Nursing List</a></li>

                        </ul>
                    </li>
                   
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">User</span></a>
                        <ul class="pcoded-submenu">
                            <li><a href="sys_forms/users.php" class="sys_links">User Registration</a></li>
                            <li><a href="sys_forms/privilege.php" class="sys_links">User privileges</a></li>
                            <li><a href="sys_forms/changepassword.php" class="sys_links">Change Password</a></li>
                        </ul>
                    </li>
            </div>
        </div>
    </nav>