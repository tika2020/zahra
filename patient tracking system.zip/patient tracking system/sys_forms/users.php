                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center m-l-0">
                            <div class="col-sm-6">
                            </div>
                            <div class="col-sm-6 text-end">
                                <button class="btn btn-success btn-sm btn-round has-ripple" data-bs-toggle="modal" data-bs-target="#modal-report"><i class="feather icon-plus"></i> Add Patient Intake</button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table id="report-table" class="table table-bordered table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Username</th>
                                        <th>Password</th>
                                        <th>Email</th>
                                        <th>Image</th>
                                        <th>Tell</th>
                                        <th>User_name</th>
                                        <th>User_date</th>
                                        <th>Usertype</th>
                                        <th>Actions</th>
                                        <!-- 
                                Id  Name  Username  Password  Email Image Tell  User_name User_date Usertype -->
                                    </tr>
                                </thead>
                                <tbody>
                                   <?php
                            include '../lib/conn.php';
                            $sql="CALL rpt_users()";
                            $res=$conn->query($sql);
                            $i=1;
                            while($row=$res->fetch_assoc()){
                          ?>
                                    <tr>
                                        
                <td><?php echo $row['Id'];?>.</td>
                <td><?php echo $row['Name'];?></td>
                <td><?php echo $row['Username'];?></td>
                <td><?php echo $row['Password'];?></td>
                <td><?php echo $row['Email'];?>.</td>
                <td><img src="<?php echo $row['Picture'];?>" width="50" height="50" class="img-circle"></td>
                <td><?php echo $row['Tell'];?></td>
                <td><?php echo $row['User_name'];?></td>
                <td><?php echo $row['User_date'];?>.</td>
                <td><?php echo $row['Usertype'];?></td>
                
                                        <td>
                                            <a href="#!" class="btn btn-info btn-sm"><i class="feather icon-edit"></i>&nbsp;Edit </a>
                                            <a href="#!" class="btn btn-danger btn-sm"><i class="feather icon-trash-2"></i>&nbsp;Delete </a>
                                        </td>
                                    </tr>
                                     <?php
                            $i++;
                            }
                          ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- customar project  end -->
        </div>
        <!-- [ Main Content ] end -->
    </div>

<div class="modal fade" id="modal-report" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Patient Intake</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
               <form  action="actions/insert.php" id="sys_forms">
                <input type="hidden" name="sp" value="sp_intake">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                    <select class="form-control" id="patient" name="patient" required="">
                          <option value="">Select Patient</option>
                          <?php
                          include '../lib/conn.php';
                          $sql="SELECT Id,Fullname FROM in_patient";
                          $res=$conn->query($sql);
                          while ($row=$res->fetch_assoc()) {
                          ?>
                            <option  value="<?php echo $row['Id']?>"><?php echo $row["Fullname"]?></option>


                          <?php
                          }
                          ?>
                        </select>
                  </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                    <select class="form-control" id="doctor_name" name="doctor_name" required="">
                          <option value="">Select Doctor</option>
                          <option value="1">dr mohamed abdi </option>
                          <option value="2">dr libaan ahmed </option>
                        </select>
                  </div>
                        </div>
                       <div class="col-sm-6">
                            <div class="form-group">
                    <select class="form-control" id="department" name="department" required="">
                          <option value="">Select Department</option>
                          <?php
                          include '../lib/conn.php';
                          $sql="SELECT Deptid,Deptname FROM departments";
                          $res=$conn->query($sql);
                          while ($row=$res->fetch_assoc()) {
                          ?>
                            <option  value="<?php echo $row['Deptid']?>"><?php echo $row["Deptname"]?></option>


                          <?php
                          }
                          ?>
                        </select>
                  </div>
                        </div>
                         <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">Age</label>
                                <input type="text" class="form-control" id="age" name="age" placeholder="Age">
                            </div>
                        </div>
                        
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="">Select Sex</label>
                                <select class="form-control" id="Sex" name="sax">
                                    <option value=""></option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Icon">patient Date</label>
                                <input type="date" class="form-control" id="pdate" name="pdate" placeholder="Patient Date" required="">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">Patient Time</label>
                                <input type="text" class="form-control" id="ptime" name="ptime" placeholder="Patient Time" required="">
                            </div>
                        </div>
                         <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">Oral</label>
                                <input type="text" class="form-control" id="oral" name="oral" placeholder="oral">
                            </div>
                        </div>
                            <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">IVI</label>
                                <input type="text" class="form-control" id="ivi" name="ivi" placeholder="ivi">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">Urine</label>
                                <input type="text" class="form-control" id="urine" name="urine" placeholder="urine">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">Drain</label>
                                <input type="text" class="form-control" id="drain" name="drain" placeholder="drain">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">Temp</label>
                                <input type="text" class="form-control" id="temp" name="temp" placeholder="temp">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">Pulse</label>
                                <input type="text" class="form-control" id="pulse" name="pulse" placeholder="pulse">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">po</label>
                                <input type="text" class="form-control" id="po" name="po" placeholder="po">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">bp</label>
                                <input type="text" class="form-control" id="bp" name="bp" placeholder="bp">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group fill">
                                <label class="floating-label" for="Birth">Res</label>
                                <input type="text" class="form-control" id="res" name="res" placeholder="res">
                            </div>
                        </div>
                        <input type="hidden" name="id" name="id" value="0">
                        <div class="col-sm-12">
                            <button type="Submit" class="btn btn-primary">Submit</button>
                            <button class="btn btn-danger">Clear</button>
                            <div class="container">
              <div class="row">
                <div class="col-md-12" id="sys_message"></div>
              </div>
          </div> 
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
</div>
