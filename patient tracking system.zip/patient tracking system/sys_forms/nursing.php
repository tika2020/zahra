                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center m-l-0">
                            <div class="col-sm-6">
                            </div>
                          
                        </div>
                        <div class="table-responsive">
                            <table id="report-table" class="table table-bordered table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                                     <th>Fullname</th>
                                                     <th>Username</th>
                                                     <th>Password</th>
                                                     <th>Email</th>
                                                     <th>Address</th>
                                                     <th>Tell</th>
                                                      <th>Picture</th>
                                                      <th>Doctor_name</th>
                                                     <th>Gender</th>
                                                     <th>Creation_date</th>
                                                      <th>User_name</th>
                                                      <th>Actions</th>
                                                     
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                            include '../lib/conn.php';
                            $sql="CALL rpt_nursing()";
                            $res=$conn->query($sql);
                            $i=1;
                            while($row=$res->fetch_assoc()){
                          ?>
                                    <tr>
                                        <!-- INSERT INTO `nurses`(`Id`, `Fullname`, `Username`, `Password`, `Email`, `Address`, `Tell`, `Picture`, `Doctor_name`, `Gender`, `Creation_date`, `User_name`, `Status`) -->
                                        
                <td><?php echo $row['Id'];?>.</td>
                <td><?php echo $row['Fullname'];?></td>
                <td><?php echo $row['Username'];?></td>
                <td><?php echo $row['Password'];?></td>
                <td><?php echo $row['Email'];?></td>
                <td><?php echo $row['Address'];?></td>
                <td><?php echo $row['Tell'];?></td>
                <td><img src="<?php echo $row['Picture'];?>" width="50" height="50" class="img-circle"></td>
                <td><?php echo $row['Doctor_name'];?></td>
                <td><?php echo $row['Gender'];?> </td>
                <td><?php echo $row['User_name'];?></td>
                <td><?php echo $row['Status'];?></td>
                       
                                        <td>
                                            <a href="#!" class="btn btn-info btn-sm"><i class="feather icon-edit"></i>&nbsp;Edit </a>
                                            <a href="#!" class="btn btn-danger btn-sm"><i class="feather icon-trash-2"></i>&nbsp;Delete </a>
                                        </td>
                                    </tr>
                                    <?php
                            $i++;
                            }
                          ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- customar project  end -->
        </div>
        <!-- [ Main Content ] end -->
    </div>
</div>
<div class="modal fade" id="modal-report" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
   </div>
</div>