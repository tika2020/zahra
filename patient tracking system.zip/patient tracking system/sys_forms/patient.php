                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center m-l-0">
                            <div class="col-sm-6">
                            </div>
                          
                        </div>
                        <div class="table-responsive">
                            <table id="report-table" class="table table-bordered table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                                     <th>Fullname</th>
                                                     <th>Address</th>
                                                     <th>Tell</th>
                                                     <th>Age</th>
                                                     <th>Gender</th>
                                                     <th>Marital_status</th>
                                                      <th>Ticket_id</th>
                                                      <th>Ticket_cost</th>
                                                     <th>Doctor_id</th>
                                                     <th>Doctor_name</th>
                                                      <th>Rate</th>
                                                     <th>Patient_type</th>
                                                     <th>Regsiteration_date</th>
                                                     <th>Added_by</th>
                                                     <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                            include '../lib/conn.php';
                            $sql="CALL rpt_patient()";
                            $res=$conn->query($sql);
                            $i=1;
                            while($row=$res->fetch_assoc()){
                          ?>
                                    <tr>
                                        
                 <td><?php echo $row['Id'];?>.</td>
                <td><?php echo $row['Fullname'];?></td>
                <td><?php echo $row['Address'];?></td>
                <td><?php echo $row['Tell'];?></td>
                <td><?php echo $row['Age'];?></td>
                <td><?php echo $row['Gender'];?></td>
                <td><?php echo $row['Marital_Status'];?></td>
                  <td><?php echo $row['Ticket_id'];?></td>
                      <td><?php echo $row['Ticket_cost'];?></td>
                    <td><?php echo $row['Doctor_id'];?> </td>
                     <td><?php echo $row['Doctor'];?></td>
                    
                      <td><?php echo $row['Rate'];?></td>
                        <td><?php echo $row['Patient_type'];?></td>
                <td><?php echo $row['Creation_date'];?></td>
                
                <td><?php echo $row['User_name'];?></td>
         
                                        <td>
                                            <a href="#!" class="btn btn-info btn-sm"><i class="feather icon-edit"></i>&nbsp;Edit </a>
                                            <a href="#!" class="btn btn-danger btn-sm"><i class="feather icon-trash-2"></i>&nbsp;Delete </a>
                                        </td>
                                    </tr>
                                    <?php
                            $i++;
                            }
                          ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- customar project  end -->
        </div>
        <!-- [ Main Content ] end -->
    </div>
</div>
<div class="modal fade" id="modal-report" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
   </div>
</div>