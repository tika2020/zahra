                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center m-l-0">
                            <div class="col-sm-6">
                            </div>
                          
                        </div>
                        <div class="table-responsive">
                            <table id="report-table" class="table table-bordered table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                                     <th>Fullname</th>
                                                     <th>Email</th>
                                                     <th>Designation</th>
                                                     <th>Department</th>
                                                     <th>City</th>
                                                     <th>Address</th>
                                                     <th>Specialist</th>
                                                     <th>Rate</th>
                                                     <th>Tell</th>
                                                     <th>Room_No</th>
                                                    <th>Picture</th>
                                                     <th>Shortbiography</th>
                                                     <th>Age</th>
                                                     <th>Bloodgroup</th>
                                                     <th>Gender</th>
                                                     <th>Status</th>
                                                     <th>User_name</th>
                                                     <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                            include '../lib/conn.php';
                            $sql="CALL rpt_doctor()";
                            $res=$conn->query($sql);
                            $i=1;
                            while($row=$res->fetch_assoc()){
                          ?>
                                    <tr>
                <!--INSERT INTO `doctors`(`Id`, `Fullname`, `Email`, `Designation`, `Department`, `Department_id`, `City`, `Address`, `Specialist`, `Rate`, `Tell`, `Room_No`, `Picture`, `Shortbiography`, `Age`, `Bloodgroup`, `Gender`, `Status`, `User_name` -->                        
                <td><?php echo $row['Id'];?>.</td>
                <td><?php echo $row['Fullname'];?></td>
                <td><?php echo $row['Email'];?></td>
                <td><?php echo $row['Designation'];?></td>
                <td><?php echo $row['Department'];?></td>
                <td><?php echo $row['City'];?></td>
                <td><?php echo $row['Address'];?></td>
                <td><?php echo $row['Specialist'];?></td>
                <td><?php echo $row['Rate'];?> </td>
                <td><?php echo $row['Tell'];?></td>
                <td><?php echo $row['Room_No'];?></td>
                <td><img src="<?php echo $row['Picture'];?>" width="50" height="50" class="img-circle"></td>
                <td><?php echo $row['Shortbiography'];?></td>
                <td><?php echo $row['Age'];?></td>
                <td><?php echo $row['Bloodgroup'];?></td>
                <td><?php echo $row['Gender'];?></td>
                <td><?php echo $row['Status'];?></td>
                <td><?php echo $row['User_name'];?></td>
                                        <td>
                                            <a href="#!" class="btn btn-info btn-sm"><i class="feather icon-edit"></i>&nbsp;Edit </a>
                                            <a href="#!" class="btn btn-danger btn-sm"><i class="feather icon-trash-2"></i>&nbsp;Delete </a>
                                        </td>
                                    </tr>
                                    <?php
                            $i++;
                            }
                          ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- customar project  end -->
        </div>
        <!-- [ Main Content ] end -->
    </div>
</div>
<div class="modal fade" id="modal-report" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
   </div>
</div>