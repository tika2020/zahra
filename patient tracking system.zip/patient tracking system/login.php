<?php
session_start();
include("lib/conn.php");
$sql="CALL sp_login('$_POST[username]','$_POST[password]')";
$res=$conn->query($sql);

if ($res) {
	$row=$res->fetch_assoc();
	if ($row["msg"]=="success") {
		$_SESSION["user_id"]=$row["id"];
	    $_SESSION["fullname"]=$row["fullname"];
         $_SESSION["username"]=$row["username"];
       
            
		echo "success";
	}
	else{
		echo $row["msg"];
	}
}
else{
	
}
?>