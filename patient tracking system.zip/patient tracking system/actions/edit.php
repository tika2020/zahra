<script type="text/javascript">
	var url="<?php echo $_GET['form_name']?>";
	$.ajax({
		url:url,
		async:false,
		success:function(data){
	 	$(".page-body").html(data);
		}
	});
	
<?php
include '../lib/conn.php';
$sql="CALL update_form('$_GET[table]','$_GET[id]')";
$res=$conn->query($sql);
if ($res) {
	$row=$res->fetch_array();
	$col=$res->fetch_fields();
	$i=0;
	foreach ($col as $value) {
	    $id=$value->name;
?>
	$("#<?php echo $id?>").val("<?php echo $row[$i]?>");
<?php
		$i++;
	}
}
?>
</script>