<?php
$sql="CALL ";
$i=0;
include '../lib/conn.php';
foreach ($_POST as $key=>$value) {
    if ($i==0) {
        $sql.=$value."(";
    }
    elseif ($key=="upload" && $i==count($_POST)-1) {
        $path="images/".$_FILES[$value];
        $sql.="'".$path."')";
    }
       elseif ($key=="upload") {
        $path="imagefiles/".$_FILES[$value]["name"];
        $sql.="'".$path."',";
    }
    elseif ($i==count($_POST)-1) {
        $sql.="'".$value."')";
    }
    else{
        $sql.="'".$value."',";
    }
    $i++;
}
$res=$conn->query($sql);
print_r($sql);
if ($res) {
    $row=$res->fetch_assoc();
    $msg=explode("|", $row["msg"]);
    if ($msg[0]=="success") {
        if (isset($_POST["upload"])) {
            $file=$_POST["upload"];
            move_uploaded_file($_FILES[$file]["tmp_name"], "../".$path);
        } 
?>
    <script>
        $("#sys_forms").each(function(){
            this.reset();
            $("#id").val(0);
        });
    </script>
<?php
    }
?> 
    <div class="alert alert-<?php echo $msg[0]?> alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fas fa-check"></i> Message</h5>
        <?php echo $msg[1];?>
    </div>
<?php
    
}
else{
?>
   
<?php
}
?>