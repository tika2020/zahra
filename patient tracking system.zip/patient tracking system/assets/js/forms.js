$(document).ready(function(){
	$(".sys_links").click(function(e){
		e.preventDefault();
		$(".center-content").empty();
		var url=$(this).attr("href");
		$.get(url,function(data){
			$(".center-content").append(data);
		   })
		});
	//jska qaybta data xaraynaysa
	$("body").on("submit","#sys_forms",function(e){
		e.preventDefault();
		var target=$(this).attr("action");
		var data=new FormData(this);
		$.ajax({
			url:target,
			data:data,
			method:"POST",
			processData:false,
			contentType:false,
			success:function(data){
				$("#sys_message").append(data);
				setTimeout(function(){
					$(".alert").remove();
				},5000);
			}
		})
	});
	 $("body").on("click",".sys_update_link",function(e){
        e.preventDefault();
        var url=$(this).attr("href");
        $.get(url,function(data){
            $(".content").html(data);
        });
    });
});