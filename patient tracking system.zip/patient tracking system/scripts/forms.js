$(document).ready(function(){
    alerts(99);
	$(".sys_links").click(function(e){
		e.preventDefault();
		$(".pcoded-content").empty();
		var url=$(this).attr("href");
		$.get(url,function(data){
			$(".pcoded-content").append(data);
		   })
		});
});