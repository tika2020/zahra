$(document).ready(function(){
	$("form").submit(function(e){
		e.preventDefault();
		var url=$(this).attr("action");
		var data=new FormData(this);
		$.ajax({
			url:url,
			data:data,
			method:"POST",
			processData:false,
			contentType:false,
			success:function(data){
			 
				if (data=="success") {
					window.location.href="index.php";
				}
				else{
					$("#msg").html(data);
					$("#msg").addClass("bg-danger");
				}
				
			}
		})
	})
})