-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2022 at 09:38 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ohms`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `address_proc` (IN `_name` VARCHAR(25))  NO SQL BEGIN 

if EXISTS(SELECT Name FROM Address a WHERE a.Name=_name) THEN
SELECT concat('danger|',_name,' Already Exist this name') msg;

ELSE
INSERT INTO Address(Name) VALUES(_name);
SELECT concat('success|',_name,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Assign_proc` (IN `_tid` INT, IN `_pn` VARCHAR(100), IN `_doc` VARCHAR(100), IN `_cost` VARCHAR(100), IN `_ptype` VARCHAR(100), IN `_un` VARCHAR(25))  NO SQL BEGIN 

INSERT INTO assigningdoc(Ticket_Id,Patient_Name,Doctor,Cost,P_Type,User_name) VALUES(_tid,_pn,_doc,_cost,_ptype,_un);
SELECT concat('success|',_pn,' Sucessfuly Assigned . ') msg;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `beds_proc` (IN `_bn` VARCHAR(50), IN `_bt` VARCHAR(3900), IN `_rn` INT, IN `_d` VARCHAR(200), IN `_ch` DOUBLE, IN `_s` VARCHAR(25), IN `_uid` INT)  NO SQL BEGIN 

INSERT INTO Beds(Bed_No,Bed_Type,Room_no,Description,Charge,Status,User_id) 
VALUES(_bn,_bt,_rn,_d,_ch,_s,_uid);
SELECT concat('success|',' Bed ',_bn,' Sucessfuly Registered To Room no ',_rn) msg;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Blodd_test_proc` (IN `_pid` INT, IN `_pname` VARCHAR(50), IN `_age` VARCHAR(20), IN `_gender` VARCHAR(20), IN `_tdate` DATE, IN `_haemog` TEXT, IN `_tlc` TEXT, IN `_neutro` TEXT, IN `_lymph` TEXT, IN `_eosino` TEXT, IN `_mono` TEXT, IN `_baso` TEXT, IN `_mchc` TEXT, IN `_mcv` TEXT, IN `_mch` TEXT, IN `_parac` TEXT, IN `_bldgrp` TEXT, IN `_plasma` TEXT, IN `_hiv` TEXT, IN `_other` TEXT, IN `_uid` INT)  NO SQL BEGIN 
INSERT INTO Blood_test
(Patient_id,Patient_name,Age,Gender,test_date,Haemoglobin,TLC,Neutrophils,Lymphocytes,Eosinophil,	Monocytes,Basophils,MCHC,MCV,	MCH,Paracytes,Blood_grouping,Plasma_fibrinogin,HIV,Others,User_id) values(_pid,_pname,_age,_gender,_tdate,_haemog,_tlc,_neutro,_lymph,_eosino,_mono,_baso,_mchc,_mcv,_mch,_parac,_bldgrp,_plasma,_hiv,_other,_uid);

SELECT concat('success|',_pname,' Sucessfuly Registered') msg;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Checkproc` (IN `p_id` INT, IN `P_n` VARCHAR(50), IN `rn` INT(25), IN `bn` VARCHAR(25), IN `bcost` FLOAT(25), IN `d_in` DATE, IN `d_out` DATE, IN `days` INT, IN `_tcharge` FLOAT, IN `u_name` VARCHAR(50))  NO SQL BEGIN 

INSERT INTO patient_check_out (Patient_Id,Patient_Name,Room_no,Bed_no,Bed_cost,Date_In,Date_Out,Days,Total_charge,User_name) VALUES(p_id,P_n,rn,bn,bcost,d_in,d_out,days,_tcharge,u_name);

SELECT concat('success|',P_n,' Sucessfuly Checked Out') msg;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `city_proc` (IN `_cname` VARCHAR(25))  NO SQL BEGIN 

if EXISTS(SELECT Cityname FROM City c WHERE c.Cityname=_cname) THEN
SELECT concat('danger|',_cname,' Already Exist this name') msg;

ELSE
INSERT INTO City(Cityname) VALUES(_cname);
SELECT concat('success|',_cname,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `dept_proc` (IN `_deptname` VARCHAR(100), IN `_desc` VARCHAR(250), IN `_status` VARCHAR(20))  NO SQL BEGIN
if EXISTS(select Deptname from departments where Deptname=_deptname) THEN
SELECT concat('danger|',_deptname,' ',' Already exists') msg;
ELSE
insert into departments (Deptname,Description,Status) values(_deptname,_desc,_status);
SELECT concat('success|',_deptname, ' ','successefully saved');
End if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `diagnosis_proc` (IN `_dname` VARCHAR(50))  NO SQL BEGIN
if EXISTS(select Diagnosis_name from diagnosis  where Diagnosis_name=_dname) THEN
SELECT concat('danger|',_dname,' ',' Already exists') msg;
ELSE
insert into diagnosis(Diagnosis_name) values(_dname);
SELECT concat('success|',_dname, ' ','successefully saved');
End if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `disease_proc` (IN `_dis` VARCHAR(20), IN `_uid` INT)  NO SQL BEGIN 

if EXISTS(SELECT Disease FROM disease d WHERE d.Disease=_dis) THEN
SELECT concat('danger|',_dis,' Already Exist') msg;

ELSE
INSERT INTO disease(Disease,User_id) VALUES(_dis,_uid);
SELECT concat('success|',_dis,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `doc_proc` (IN `_fname` VARCHAR(50), IN `_uname` VARCHAR(50), IN `_pass` VARCHAR(100), IN `_email` VARCHAR(100), IN `_design` VARCHAR(50), IN `_dep` VARCHAR(50), IN `_deptid` INT, IN `_city` VARCHAR(50), IN `_add` VARCHAR(50), IN `_spec` VARCHAR(80), IN `_tell` INT, IN `_roomno` INT, IN `_pic` VARCHAR(200), IN `_shbio` VARCHAR(15), IN `_age` VARCHAR(100), IN `_bgroup` VARCHAR(20), IN `_gen` VARCHAR(20), IN `_stat` VARCHAR(100), IN `_rate` INT, IN `_uid` VARCHAR(50))  NO SQL BEGIN 

if EXISTS(SELECT Email FROM doctors d WHERE d.Email=_email) THEN
SELECT concat('danger|',_email,' Already Exist this email') msg;

ELSE
INSERT INTO doctors(Fullname,Email,Designation,Department,Department_id,City,Address,Specialist,Rate,Tell,Room_no,Picture,Shortbiography,Age,Bloodgroup,Gender,Status,User_name) VALUES(_fname,_email,_design,_dep,_deptid,_city,_add,_spec,_rate,_tell,_roomno,_pic,_shbio,_age,_bgroup,_gen,_stat,_uid);
INSERT INTO user(Name,Username,Password,Email,Image,Tell,User_name,Usertype) values(_fname,_uname,md5(_pass),_email,_pic,_tell,_uid,'Doctor');

SELECT concat('success|',_fname,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `doc_spec_sp` (IN `_spname` VARCHAR(50))  NO SQL BEGIN
if EXISTS(select Specialist_name from specialists where Specialist_name=_spname) THEN
SELECT concat('danger|',_spname,' ',' Already exists') msg;
ELSE
insert into specialists (Specialist_name) values(_spname);
SELECT concat('success|',_spname, ' ','successefully saved');
End if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `druggroup_proc` (IN `_droup` VARCHAR(50), IN `_un` VARCHAR(25))  NO SQL BEGIN 

if EXISTS(SELECT Drug_group FROM druggroup d WHERE d.Drug_group=_droup) THEN
SELECT concat('danger|',_droup,' Already Exist') msg;

ELSE
INSERT INTO druggroup(Drug_group,User_name) VALUES(_droup,_un);
SELECT concat('success|',_droup,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `drugs_proc` (IN `_dnid` INT, IN `_dname` VARCHAR(100), IN `_dt` VARCHAR(100), IN `_dg` VARCHAR(50), IN `_pri` FLOAT, IN `_com` VARCHAR(100), IN `_ed` DATE, IN `_qnty` INT, IN `_un` VARCHAR(50))  NO SQL BEGIN 

INSERT INTO drugs(Drug_name_id,Drug_name,Drug_type,Drug_group,Price,Company,Expired_date,Quantity,User_name) VALUES(_dnid,_dname,_dt,_dg,_pri,_com,_ed,_qnty,_un);
SELECT concat('success|',_dname,' Sucessfuly Registered') msg;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `drugtype_proc` (IN `d_type` VARCHAR(50), IN `_date` VARCHAR(25), IN `_un` VARCHAR(25))  NO SQL BEGIN 

if EXISTS(SELECT Drug_type FROM drugtype d WHERE d.Drug_type=d_type) THEN
SELECT concat('danger|',d_type,' Already Exist') msg;

ELSE
INSERT INTO drugtype(Drug_type,Creation_date,User_name) VALUES(d_type,_date,_un);
SELECT concat('success|',d_type,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `emp_proc` (IN `_name` VARCHAR(100), IN `_email` VARCHAR(25), IN `_mob` INT, IN `_add` VARCHAR(200), IN `_gen` VARCHAR(25), IN `_pic` VARCHAR(200), IN `_bday` DATE, IN `_hdate` DATE, IN `_dept` VARCHAR(50), IN `_sal` DOUBLE, IN `_stat` VARCHAR(25), IN `_uname` VARCHAR(25))  NO SQL BEGIN


INSERT INTO employee(Fullname,Email,Mobile,Address,Gender,Picture,Birth_day,Hire_date,Department,Salary,Status,User_name) VALUES(_name,_email,_mob,_add,_gen,_pic,_bday,_hdate,_dept,_sal,_stat,_uname);
SELECT concat('success|',_name,' Sucessfuly Registered') msg;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inappointment_proc` (IN `_pname` VARCHAR(50), IN `_t` INT, IN `_e` VARCHAR(50), IN `_depname` INT, IN `_docname` VARCHAR(50), IN `_date` DATE, IN `_tno` INT, IN `_prob` VARCHAR(500), IN `_stat` VARCHAR(25), IN `_cancel` VARCHAR(25), IN `_uid` INT)  NO SQL BEGIN 

INSERT INTO in_appointment(Patient_name,Tell,Email,Department_name,Doctor_name,Appointment_date_time,Ticket_No,Problem,Status,Canceled,User_id) VALUES(_pname,_t,_e,_depname,_docname,_date,_tno,_prob,'Active','No',_uid);
SELECT concat('success|',_pname,' Sucessfuly Registered') msg;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inpatient_proc` (IN `_pid` INT, IN `_pname` VARCHAR(50), IN `_docn` VARCHAR(70), IN `_rno` INT, IN `_bedno` VARCHAR(20), IN `_bcost` DOUBLE, IN `_rdays` DATE, IN `_order` VARCHAR(200), IN `_ope` VARCHAR(10), IN `_optype` VARCHAR(70), IN `_opcost` FLOAT, IN `_p_u_op` VARCHAR(50), IN `_rate` INT, IN `_un` VARCHAR(50))  NO SQL BEGIN 


INSERT INTO in_patient (Patient_id,Fullname,Doctor,Room_No,Bed_No,Bed_cost,Reg_date,Orders,Operation,Operation_type,Cost,P_U_operation,Rate,User_name) VALUES(_pid,_pname,_docn,_rno,_bedno,_bcost,_rdays,_order,_ope,_optype,_opcost,_p_u_op,_rate,_un);

SELECT concat('success|',_pname,' Sucessfuly Registered') msg;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `labreg_proc` (IN `_name` VARCHAR(50), IN `_uname` VARCHAR(50), IN `_pass` VARCHAR(200), IN `_em` VARCHAR(50), IN `_add` VARCHAR(50), IN `_tell` VARCHAR(25), IN `_pic` VARCHAR(200), IN `_gen` VARCHAR(20), IN `_un` VARCHAR(25), IN `_stat` VARCHAR(15))  NO SQL BEGIN 

if EXISTS(SELECT Email FROM laboratoristreg l WHERE l.Email=_em) THEN
SELECT concat('danger|',_em,' Already Exist this email') msg;

ELSE
INSERT INTO laboratoristreg (Name,Email,Address,Tell,Picture,Gender,User_name,Status) VALUES(_name,_em,_add,_tell,_pic,_gen,_un,_stat);
INSERT INTO user(Name,Username,Password,Email,Image,Tell,User_name,Usertype) values(_name,_uname,md5(_pass),_em,_pic,_tell,_un,'Labortorist');

SELECT concat('success|',_name,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `login_sp` (IN `_user` VARCHAR(45), IN `_pass` VARCHAR(50))  NO SQL BEGIN

if exists(SELECT * FROM user where Username = _user  and Password = md5(_pass)) THEN

SELECT Id,Username, 'Login success' as msg, Image FROM user where Username = _user and Password = md5(_pass);

ELSE

SELECT 'Login Failed' msg;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `nurse_proc` (IN `_fname` VARCHAR(50), IN `_uname` VARCHAR(50), IN `_pass` VARCHAR(200), IN `_em` VARCHAR(50), IN `_add` VARCHAR(50), IN `_tell` VARCHAR(25), IN `_pic` VARCHAR(200), IN `_docn` VARCHAR(50), IN `_gen` VARCHAR(20), IN `_un` VARCHAR(25), IN `_stat` VARCHAR(10))  NO SQL BEGIN 

if EXISTS(SELECT Email FROM nurses n WHERE n.Email=_em) THEN
SELECT concat('danger|',_em,' Already Exist this email') msg;

ELSE
INSERT INTO nurses(Fullname,Username,Password,Email,Address,Tell,Picture,Doctor_name,Gender,User_name,Status) VALUES(_fname,_uname,md5(_pass),_em,_add,_tell,_pic,_docn,_gen,_un,_stat);
INSERT INTO user(Name,Username,Password,Email,Image,Tell,User_name,Usertype) values(_fname,_uname,md5(_pass),_em,_pic,_tell,_un,'Nurse');

SELECT concat('success|',_fname,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Oper_proc` (IN `_ot` VARCHAR(200), IN `_r` INT, IN `_un` VARCHAR(25))  NO SQL BEGIN 

INSERT INTO operations(O_Type,Rate,User_name) VALUES(_ot,_r,_un);
SELECT concat('success|',_ot,' Sucessfuly Registered ') msg;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `patient_proc` (IN `_fname` VARCHAR(70), IN `_add` VARCHAR(15), IN `_tell` VARCHAR(25), IN `_age` VARCHAR(12), IN `_gen` VARCHAR(10), IN `_mstatus` VARCHAR(15), IN `_tid` INT, IN `_tcst` INT, IN `_docid` INT, IN `_dname` VARCHAR(50), IN `_rate` DOUBLE, IN `_ptype` VARCHAR(50), IN `_cdate` DATE, IN `_uname` VARCHAR(50))  NO SQL BEGIN 

if EXISTS(SELECT Tell FROM patients p WHERE p.Tell=_tell) THEN
SELECT concat('danger|',_tell,' Already Exist') msg;




ELSE
INSERT INTO patients(Fullname,Address,Tell,Age,Gender,Marital_Status,Ticket_id,Ticket_cost,Doctor_id,Doctor,Rate,Patient_type,Creation_date,User_name) VALUES(_fname,_add,_tell,_age,_gen,_mstatus,_tid,_tcst,_docid,_dname,_rate,_ptype,_cdate,_uname);
SELECT concat('success|',_fname,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pat_diagnosis_proc` (IN `_pid` INT, IN `_name` VARCHAR(50), IN `_pddate` VARCHAR(50), IN `_provdiag` VARCHAR(25), IN `_remark` VARCHAR(25), IN `_biochem` VARCHAR(25), IN `_stool` VARCHAR(25), IN `_blood` VARCHAR(25), IN `_colon` VARCHAR(25), IN `_gast` VARCHAR(25), IN `_urine` VARCHAR(25), IN `_xray` VARCHAR(25), IN `_sonog` VARCHAR(25), IN `_ecg` VARCHAR(25), IN `_others` VARCHAR(25), IN `_recadvwk` VARCHAR(25), IN `_findiag` VARCHAR(25), IN `_uid` INT)  NO SQL BEGIN 
INSERT INTO patient_diagnosis
(Patient_id,Name,Diagnosis_date,Prov_diagnosis,Remark,Bio_chemestry,Stool,Blood,Colonoscopy,Gastroscopy,Urine,XRay,SONOGRAPHY,Others,Reconsultation_Advice_Week,Final_diagnosis,ECG,User_id) values(_pid,_name,_pddate,_provdiag,_remark,_biochem,_stool,_blood,_colon,_gast,_urine,_xray,_sonog,_ecg,_others,_recadvwk,_findiag,_uid);

SELECT concat('success|',_name,' Sucessfuly Registered') msg;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `permission_proc` (IN `_user` INT, IN `_sidebar` INT, IN `_action` VARCHAR(50))  NO SQL BEGIN
IF(_action = 'grant') THEN
insert into permission (User_id,Sidebar_id) VALUES (_user,_sidebar);
ELSE
delete from permission where User_id=_user and Sidebar_id=_sidebar;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pharmtran_proc` (IN `_pid` INT, IN `_pname` VARCHAR(50), IN `_tid` INT, IN `_dnno` SMALLINT, IN `_dname` VARCHAR(50), IN `_dtype` VARCHAR(50), IN `_quant` INT, IN `_price` DOUBLE, IN `_disc` FLOAT, IN `_total` DOUBLE, IN `_uname` VARCHAR(50))  NO SQL BEGIN 

INSERT INTO pharmacytran(Patient_id,Patient_name,Ticket_id,Drug_name_id,Drug_name,Drug_type,Quantity,Price,Discount,Total,User_name) 
VALUES(_pid,_pname,_tid,_dnno,_dname,_dtype,_quant,_price,_disc,_total,_uname);
SELECT concat('success|',_pname,' Sucessfuly Registered') msg;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `phar_proc` (IN `_Ful` VARCHAR(200), IN `_uname` VARCHAR(300), IN `_Pass` VARCHAR(400), IN `_eml` VARCHAR(500), IN `_pic` VARCHAR(500), IN `_tell` VARCHAR(1400), IN `_gen` VARCHAR(500), IN `_add` VARCHAR(200), IN `_stat` VARCHAR(25), IN `_un` VARCHAR(25))  NO SQL BEGIN 

if EXISTS(SELECT Email FROM pharmacist u WHERE u.Email=_eml) THEN
SELECT concat('danger|',_eml,' Already Exist') msg;

ELSE


INSERT INTO pharmacist(Fullname,Username,Password,Email,Picture,Mobile,Gender,Address,Status,User_name) VALUES(_Ful,_uname,_Pass,_eml,_pic,_tell,_gen,_add,_stat,_un);
INSERT INTO user(Name,Username,Password,Email,Image,Tell,User_name,Usertype) values(_Ful,_uname,md5(_pass),_eml,_pic,_tell,_un,'Pharmacist');
SELECT concat('success|',_Ful,' Sucessfuly Registered  ') msg;

end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_check_code` (IN `_email` VARCHAR(50), IN `_code` INT)  NO SQL BEGIN

if exists(select id from user_send_code where email = _email and `code` = _code) THEN

SELECT id into @user from user where email = _email;

select 'success', @user uid;

else

select 'error';
end if;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_send_code` (IN `p_user` VARCHAR(50))  NO SQL BEGIN

if exists(SELECT Email  FROM `user` WHERE Username = p_user OR Email = p_user) THEN

SELECT Email into @email FROM `user` WHERE Username = p_user OR Email = p_user ;

SET @code = gen_code();

INSERT INTO user_send_code (email,`code`) VALUES (@email,@code);

SELECT @email email,@code `code`;

else

select 'The email, user, or phone Not Found';

end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rooms_proc` (IN `_rno` INT, IN `_rtype` VARCHAR(25), IN `_nofbeds` INT, IN `_rcost` DOUBLE, IN `_stat` VARCHAR(20), IN `_usrid` INT)  NO SQL BEGIN 

if EXISTS(SELECT RoomNo FROM Rooms r WHERE r.RoomNo=_rno) THEN
SELECT concat('danger|',_rno,' Already Exist') msg;

ELSE
INSERT INTO Rooms(RoomNo,RoomType,No_of_Beds,RoomCost,Status,User_id) VALUES(_rno,_rtype,_nofbeds,_rcost,_stat,_usrid);
SELECT concat('success|',_rno,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `roomtype_proc` (IN `_rtype` VARCHAR(15), IN `_beds` VARCHAR(15), IN `_un` VARCHAR(25))  NO SQL BEGIN 

if EXISTS(SELECT Room_type FROM Roomtype rt WHERE rt.Room_type=_rtype) THEN
SELECT concat('danger|',_rtype,' Already Exist') msg;

ELSE
INSERT INTO Roomtype(Room_type,Beds,User_name) VALUES(_rtype,_beds,_un);
SELECT concat('success|',_rtype,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rpt_doctor` ()   BEGIN
	SELECT t.Id,t.Fullname,t.Email,t.Designation,t.Department,t.City,
    t.Address,t.Specialist,t.Rate,t.Tell,t.Room_No,t.Picture,
    t.Shortbiography,t.Age,t.Bloodgroup,t.Gender,t.Status,t.User_name
,concat
('<a href="actions/edit.php?table=doctors&form_name=doctor.php&id=',t.Id,'" class="btn btn-success sys_update_link"><i class="fas fa-edit"></i></a>') as "edit",concat
 
 
 ('<a href="actions/delete.php?table=test&id='
 ,t.Id,'"></a>') FROM  doctors t ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rpt_intake` ()   BEGIN
	SELECT t.id,p.Fullname as'patient_name',d.Fullname,s.Deptname,t.age
    ,t.sex,t.pdate,t.ptime,t.oral,t.ivi,t.urine,t.drain
    ,t.temp,t.pulse,t.po,t.bp,t.res
,concat
('<a href="actions/edit.php?table=intake&form_name=sys_forms/intake.php&id=',t.id,'" class="btn btn-success sys_update_link"><i class="fas fa-edit"></i></a>') as "edit",concat
 
 
 ('<a href="actions/delete.php?table=test&id='
 ,t.id,'"></a>') FROM  intake t JOIN departments s on t.department=s.Deptid JOIN doctors d on t.doctor_name=d.Id JOIN patients p on t.ipno=p.Id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rpt_nursing` ()   BEGIN
	SELECT t.Id,t.Fullname,t.Username,t.Password,t.Email,
    t.Address,t.Tell,t.Picture,t.Doctor_name,t.Gender,
    t.Creation_date,t.User_name,t.Status
,concat
('<a href="actions/edit.php?table=nurses&form_name=sys_forms/nursesng.php&id=',t.Id,'" class="btn btn-success sys_update_link"><i class="fas fa-edit"></i></a>') as "edit",concat
 
 
 ('<a href="actions/delete.php?table=nurses&id='
 ,t.Id,'"></a>') FROM  nurses t ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rpt_patient` ()   BEGIN
	SELECT t.Id,t.Fullname,t.Address,t.Tell,t.Age,t.Gender,t.Marital_Status
    ,t.Ticket_id,t.Ticket_cost,t.Doctor_id,t.Doctor,t.Rate,t.Patient_type
    ,t.Creation_date,t.User_name
,concat
('<a href="actions/edit.php?table=patients&form_name=patients.php&id=',t.Id,'" class="btn btn-success sys_update_link"><i class="fas fa-edit"></i></a>') as "edit",concat
 
 
 ('<a href="actions/delete.php?table=test&id='
 ,t.Id,'"></a>') FROM  patients t ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rpt_progress_note` ()  NO SQL BEGIN
	SELECT pn.pname,pn.age,pn.rn,pn.diagnosis,pn.pdate,pn.progressnote,pn.description
,concat
('<a href="actions/edit.php?table=proggress_note&form_name=rptproggress_note.php&id=',pn.prid,'" class="btn btn-success sys_update_link"><i class="fas fa-edit"></i></a>') as "edit",concat
 
 
 ('<a href="actions/delete.php?table=test&id='
 ,pn.prid,'"></a>') FROM  proggress_note pn ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rpt_treatment` ()  NO SQL BEGIN
	SELECT t.Treatment_id,t.Patient_id,t.Patient_name,t.Doctor_name,t.Ticket_id,t.Reg_date,t.Drug,t.Quantity,t.Frequency_X,t.Duration,t.Route,t.Stopped,t.Stopped_date,t.Added_by,t.Tdate,t.Ttime
,concat
('<a href="actions/edit.php?table=treatment&form_name=rpttreatment.php&id=',t.Treatment_id,'" class="btn btn-success sys_update_link"><i class="fas fa-edit"></i></a>') as "edit",concat
 
 
 ('<a href="actions/delete.php?table=test&id='
 ,t.Treatment_id,'"></a>') FROM  treatment t ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rpt_users` ()   BEGIN
	SELECT t.Id,t.Name,t.Username,t.Password,t.Email,t.Image,
    t.Tell,t.User_name,t.User_date,t.Usertype
,concat
('<a href="actions/edit.php?table=nurses&form_name=sys_forms/nursesng.php&id=',t.Id,'" class="btn btn-success sys_update_link"><i class="fas fa-edit"></i></a>') as "edit",concat
 
 
 ('<a href="actions/delete.php?table=nurses&id='
 ,t.Id,'"></a>') FROM  user t ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `schedule_proc` (IN `_docname` VARCHAR(50), IN `_adays` VARCHAR(100), IN `_atime` VARCHAR(25), IN `_pptime` VARCHAR(25), IN `_svisib` VARCHAR(25), IN `_stat` VARCHAR(25), IN `_uname` VARCHAR(50))  NO SQL BEGIN
if EXISTS(SELECT Name FROM schedule s WHERE s.Name=_docname) THEN
SELECT concat('danger|',_docname,' Already Exist') msg;

ELSE
INSERT INTO schedule(Name,Available_days,Available_time,per_patient_time,Serial_visibility,Status,User_name) VALUES(_docname,_adays,_atime,_pptime,_svisib,_stat,_uname);
SELECT concat('success|',_docname,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Sidebar_proc` (IN `_href` VARCHAR(100), IN `_txt` VARCHAR(50), IN `_icon` VARCHAR(50), IN `_menu` VARCHAR(50))  NO SQL BEGIN 
if EXISTS(select href from sidebar where href=_href) THEN
SELECT concat('danger|',_href,' ',' Already exists') msg;
ELSE

INSERT INTO sidebar(href,text,icon,menu) VALUES(_href,_txt,_icon,_menu);
SELECT concat('success|',_txt,' Sucessfuly Registered') msg;
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_change_pass` (IN `_old` VARCHAR(50), IN `_user` INT, IN `_pass` VARCHAR(50), IN `_confirm` VARCHAR(50), IN `_action` VARCHAR(25))  NO SQL BEGIN

if(_action = 'change') THEN
if not exists(select Id from user where Id = _user and Password = md5(_old)) THEN

select 'danger|Incorrect Old Password' as msg;


elseif (_pass != _confirm) THEN



select 'danger|Password mis match' as msg;


elseif(_old = _pass) THEN

select 'warning|Old Password and New Password are same' as msg;





else

update user set Password = md5(_pass) where Id = _user ;
select 'success|Password Changed' as msg;


end if;


elseif (_action = 'reset') THEN
if (_pass != _confirm) THEN


select 'danger|Password mis match' as msg;

else

update user set Password = md5(_pass) where Id = _user ;
select 'success|Password Reset' as msg;

end if;
end if;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_intake` (IN `p_patient_name` VARCHAR(50), IN `p_doctor_name` INT(50), IN `p_department` INT(50), IN `p_age` VARCHAR(50), IN `p_sex` VARCHAR(50), IN `p_pdate` VARCHAR(50), IN `p_ptime` VARCHAR(50), IN `p_oral` VARCHAR(50), IN `p_ivi` VARCHAR(50), IN `p_urine` VARCHAR(50), IN `p_drain` VARCHAR(50), IN `p_temp` VARCHAR(50), IN `p_pulse` VARCHAR(50), IN `p_po` VARCHAR(50), IN `p_bp` VARCHAR(50), IN `p_res` VARCHAR(50), IN `p_id` INT)  NO SQL BEGIN
IF EXISTS(SELECT * FROM intake i WHERE i.id=p_id) THEN
	UPDATE intake i SET i.ipno=p_patient_name,i.department=p_department,i.name=p_doctor_name,i.age=p_age,i.sex=p_sex,i.doa=p_doa,i.diagnosis=p_diagnosis,i.pdate=p_pdate
    ,i.ptime=p_ptime,i.oral=p_oral,i.ivi=p_ivi,i.urine=p_urine,i.drain=p_drain,i.temp=p_temp,i.pulse=p_pulse,i.po=p_po,i.bp=p_bp,i.res=p_res
    WHERE i.id=p_id;
    SELECT "success|intake Updated Successfully" msg; 

ELSE
	INSERT INTO `intake`(`id`, `ipno`, `doctor_name`, `department`, `age`, `sex`, `pdate`, `ptime`, `oral`, `ivi`, `urine`, `drain`, `temp`, `pulse`, `po`, `bp`, `res`) VALUES (NULL,p_patient_name,p_doctor_name,p_department ,p_age,p_sex,p_pdate,p_ptime,p_oral,p_ivi,p_urine,p_drain,p_temp,p_pulse,p_po,p_bp,p_res);
    SELECT "success|intake registered succesfully" msg;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_login` (IN `p_username` VARCHAR(30), IN `p_password` VARCHAR(30))   BEGIN
IF EXISTS(SELECT * FROM users u WHERE u.username=p_username AND u.password=p_password) THEN
	SELECT u.id,u.fullname,u.username,  "success" msg FROM users u WHERE u.username=p_username AND u.password=p_password;
ELSE
	SELECT "Username or password is incorrect" msg;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_progress_note` (IN `p_pname` VARCHAR(100), IN `p_age` VARCHAR(100), IN `p_rn` VARCHAR(100), IN `p_diagnosis` VARCHAR(100), IN `p_pdate` VARCHAR(100), IN `p_progressnote` VARCHAR(500), IN `p_description` VARCHAR(100), IN `p_id` INT(11))  NO SQL BEGIN
IF EXISTS(SELECT * FROM proggress_note pn WHERE pn.prid=p_id) THEN
	UPDATE proggress_note pn SET pn.pname=p_pname,pn.age=p_age,pn.rn=p_rn,pn.diagnosis=p_diagnosis,pn.pdate=p_pdate,pn.progressnote=p_progressnote,pn.description=p_description
    WHERE pn.prid=p_id;
    SELECT "success|progress note Updated Successfully" msg; 

ELSE
	INSERT INTO `proggress_note`(`prid`, `pname`, `age`, `rn`, `diagnosis`, `pdate`, `progressnote`, `description`) VALUES 
    
    (NULL,p_pname,p_age,p_rn,p_diagnosis,p_pdate,p_progressnote,p_description);
    SELECT "success|progress note registered succesfully" msg;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_treatment` (IN `p_Patient_id` INT(11), IN `p_Patient_name` VARCHAR(50), IN `p_Doctor_name` VARCHAR(50), IN `p_Ticket_id` INT(11), IN `p_Reg_date` DATE, IN `p_Drug` VARCHAR(200), IN `p_Quantity` INT(11), IN `p_Frequency_X` VARCHAR(100), IN `p_Duration` VARCHAR(50), IN `p_Route` TEXT, IN `p_Stopped` VARCHAR(10), IN `p_Stopped_date` DATE, IN `p_Added_by` VARCHAR(50), IN `p_Tdate` VARCHAR(100), IN `p_Ttime` VARCHAR(100), IN `p_id` INT(11))  NO SQL BEGIN
IF EXISTS(SELECT * FROM treatment t WHERE t.Treatment_id=p_id) THEN
	UPDATE treatment t SET t.Patient_id=p_Patient_id,t.Patient_name=p_Patient_name,t.Doctor_name=p_Doctor_name,t.Ticket_id=p_Ticket_id,t.Reg_date=p_Reg_date,
t.Drug=p_Drug,t.Quantity=p_Quantity,t.Frequency_X=p_Frequency_X,t.Duration=p_Duration,t.Route=p_Route,t.Stopped=p_Stopped,t.Stopped_date=p_Stopped_date,
  t.Added_by=p_Added_by,t.Tdate=p_Tdate,t.Ttime=p_Ttime
    
    WHERE t.Treatment_id=p_id;
    SELECT "success|treatment Updated Successfully" msg; 

ELSE
	INSERT INTO `treatment`(`Treatment_id`, `Patient_id`, `Patient_name`, `Doctor_name`, `Ticket_id`, `Reg_date`, `Drug`, `Quantity`, `Frequency_X`, `Duration`, `Route`, `Stopped`, `Stopped_date`, `Added_by`, `Tdate`, `Ttime`) VALUES (NULL,p_Patient_id,p_Patient_name,p_Doctor_name,p_Ticket_id,p_Reg_date,p_Drug,p_Quantity,p_Frequency_X,p_Duration,p_Route,p_Stopped,p_Stopped_date,p_Added_by,p_Tdate,p_Ttime);
    SELECT "success|treatment registered succesfully" msg;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_users` (IN `p_fullname` VARCHAR(100), IN `p_Phone` VARCHAR(50), IN `p_address` VARCHAR(200), IN `p_username` VARCHAR(50), IN `p_userType` INT, IN `p_password` VARCHAR(50), IN `p_image` VARCHAR(200), IN `p_user_id` INT, IN `p_id` INT)  NO SQL BEGIN
IF EXISTS(SELECT * FROM users b WHERE b.id=p_id) THEN
	UPDATE users b SET b.fullname=p_fullname,b.Phone=p_Phone,b.address=p_address
    ,b.username=p_username,b.userType=p_userType,b.password=p_password,b.image=p_image,b.user_id=p_user_id,b.date=p_date
     WHERE d.id=p_id;
    SELECT "success|users Updated Successfully" msg; 
ELSEIF EXISTS(SELECT * FROM users b WHERE b.username=p_username) THEN
	SELECT "warning|users already exists" msg;
ELSE
	INSERT INTO `users`(`id`, `fullname`, `Phone`, `address`, `username`, `userType`, `password`,`image`, `user_id`, `date`) VALUES (null,p_fullname,p_Phone,p_address,p_username,p_userType,p_password,p_image,p_user_id,CURRENT_TIMESTAMP);
    SELECT "success|users registered succesfully" msg;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tablet_syrups_proc` (IN `_dname` VARCHAR(50))  NO SQL BEGIN
if EXISTS(select Name from tablet_syrups  where Name=_dname) THEN
SELECT concat('danger|',_dname,' ',' Already exists') msg;
ELSE
insert into tablet_syrups(Name) values(_dname);
SELECT concat('success|',_dname, ' ','successefully saved');
End if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_form` (IN `p_table` VARCHAR(50), IN `p_id` INT)   BEGIN
if p_table ="intake" THEN
select
d.id"id",d.ipno"patient",d.doctor_name"doctor_name",d.department"department"
,d.age"age",d.sex"sax",d.pdate"pdate",
d.ptime"ptime",d.oral"oral",d.ivi"ivi",d.urine"urine",d.drain"drain"
,d.temp"temp",d.pulse"pulse",d.po"po",
d.bp"bp",d.res"res"
  from intake d WHERE d.id=p_id;
 
 END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `user_proc` (IN `_name` VARCHAR(100), IN `_username` VARCHAR(100), IN `_password` VARCHAR(100), IN `_confirm` VARCHAR(100), IN `_email` VARCHAR(50), IN `_image` VARCHAR(200), IN `_tell` VARCHAR(50), IN `_user_n` VARCHAR(25), IN `_utype` VARCHAR(20))  NO SQL BEGIN 

if EXISTS(SELECT Username FROM user u WHERE u.Username=_username) THEN
SELECT concat('danger|',_username,' Already Exist') msg;

elseif(_password != _confirm) THEN

SELECT concat('danger|Password mis match') msg;


ELSE
INSERT INTO user(Name,Username,Password,Email,Image,Tell,User_name,Usertype) VALUES(_name,_username,md5(_password),_email,_image,_tell,_user_n,_utype);
SELECT concat('success|',_username,' Sucessfuly Registered') msg;
end if;
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `gen_code` () RETURNS INT(11) NO SQL BEGIN

SET @code = 1001;

SELECT `code`+id into @code FROM `user_send_code` order by `code` desc  limit 1;


return @code;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `Id` int(11) NOT NULL,
  `Name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`Id`, `Name`) VALUES
(1, 'Wadajir'),
(2, 'Dharkenley'),
(3, 'Waaberi'),
(4, 'Xamarweyne'),
(5, 'Xamarjajab'),
(6, 'Yaaqshiid'),
(7, 'Boondheere'),
(8, 'A/aziz'),
(9, 'Wartanabadda'),
(10, 'Shangaani'),
(11, 'Dayniile'),
(12, 'Kaxda'),
(13, 'Heliwaa'),
(14, 'Hodan'),
(15, 'Howlwadaag'),
(16, 'Shibiz'),
(17, 'Kaaraan'),
(18, 'Owdhigle'),
(19, 'Afgooye'),
(20, 'Marka'),
(21, 'Qoryooley'),
(22, 'Baraawe'),
(23, 'Janaale'),
(24, 'Bariire'),
(25, 'Jowhar'),
(26, 'Balcad'),
(27, 'Warshiiq');

-- --------------------------------------------------------

--
-- Table structure for table `assigningdoc`
--

CREATE TABLE `assigningdoc` (
  `Id` int(11) NOT NULL,
  `Ticket_Id` int(11) NOT NULL,
  `Patient_Name` varchar(100) NOT NULL,
  `Doctor` varchar(100) NOT NULL,
  `Cost` varchar(600) NOT NULL,
  `P_Type` varchar(40) NOT NULL,
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assigningdoc`
--

INSERT INTO `assigningdoc` (`Id`, `Ticket_Id`, `Patient_Name`, `Doctor`, `Cost`, `P_Type`, `User_name`) VALUES
(10, 1200, 'Saafi Ali Hasan', '12', '40', 'Emergency', '10'),
(11, 6700, 'Saafi Ali Hasan', '14', '40', 'Emergency', '10'),
(12, 4500, 'Filsan', '10', '40', 'Emergency', '10'),
(13, 1300, 'Sayidka', '11', '40', 'Emergency', '10'),
(14, 6700, 'Saafi Ali Hasan', '1', '70', 'OutPatient', '17'),
(15, 6700, 'Filsan', '12', '90', 'Delivery', '17'),
(16, 4, 'Saafi Ali Hasan', '18', '100', 'Delivery', '8'),
(17, 8, 'Ruqiyo Ahmed Nur', '20', '20', 'Emergency', 'AIsha'),
(18, 56778, 'jaamac', '15', '100', 'Emergency', 'AIsha'),
(19, 1, 'Abdi Nur Ali', '20', '20', 'Emergency', 'hashi2'),
(20, 66666, 'Abdi Nur Ali', '13', '90', 'OutPatient', 'hashi2');

-- --------------------------------------------------------

--
-- Table structure for table `beds`
--

CREATE TABLE `beds` (
  `Id` int(11) NOT NULL,
  `Bed_No` varchar(110) NOT NULL,
  `Bed_Type` varchar(600) NOT NULL,
  `Room_no` int(11) NOT NULL,
  `Description` varchar(3800) NOT NULL,
  `Charge` int(11) NOT NULL,
  `C_Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Status` varchar(300) NOT NULL,
  `User_Id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `beds`
--

INSERT INTO `beds` (`Id`, `Bed_No`, `Bed_Type`, `Room_no`, `Description`, `Charge`, `C_Date`, `Status`, `User_Id`) VALUES
(1, 'B1', 'U-High', 13, 'The Best Bed', 150, '2019-07-30 12:35:28', 'InActive', 10),
(2, 'B2', 'U-High', 13, 'The Second Best Bed', 100, '2019-07-20 11:03:11', 'InActive', 10),
(3, 'B3', 'Normal', 13, 'NO', 20, '2019-07-21 07:48:37', 'InActive', 2),
(4, 'B4', 'High', 1, 'd', 160, '2019-08-17 08:58:46', 'InActive', 23),
(5, 'B5', 'High', 1, 'no', 20, '2019-07-17 12:01:38', 'Active', 23),
(6, 'B6', 'High', 1, 'no', 20, '2019-09-18 18:06:59', 'InActive', 23),
(7, 'B7', 'High', 1, 'no', 20, '2019-08-02 18:20:24', 'InActive', 23),
(8, 'B8', 'High', 1, 'no', 20, '2019-09-19 04:59:52', 'Active', 23),
(9, 'B9', 'High', 1, 'no', 20, '2019-07-17 12:01:38', 'Active', 23),
(10, 'B10', 'Normal', 2, 'no', 20, '2019-07-17 12:01:38', 'Active', 23),
(11, 'B11', 'Normal', 2, 'no', 20, '2019-08-19 12:05:23', 'InActive', 23),
(12, 'B12', 'Normal', 2, 'no', 15, '2019-07-22 10:50:21', 'InActive', 23),
(13, 'B13', 'Normal', 2, 'no', 15, '2019-09-12 07:45:47', 'Active', 23),
(14, 'B14', 'Normal', 2, 'no', 15, '2019-09-12 08:46:14', 'Active', 23),
(16, 'B16', 'Normal', 3, 'no', 10, '2019-08-02 17:45:33', 'InActive', 23),
(17, 'B17', 'Normal', 3, 'no', 10, '2019-07-17 12:01:38', 'Active', 23),
(18, 'B18', 'Normal', 3, 'no', 10, '2019-09-18 13:17:42', 'InActive', 23),
(19, 'B19', 'Normal', 3, 'no', 10, '2019-07-17 12:01:38', 'Active', 23),
(20, 'B20', 'High', 4, 'no', 30, '2019-07-17 12:01:38', 'Active', 23),
(21, 'B21', 'High', 4, 'no', 30, '2019-07-17 12:01:38', 'Active', 23),
(22, 'B22', 'High', 4, 'no', 30, '2019-07-17 12:01:38', 'Active', 23),
(23, 'B23', 'High', 4, 'no', 30, '2019-07-17 12:01:38', 'Active', 23),
(24, 'B24', 'High', 5, 'no', 50, '2019-07-23 08:47:15', 'Active', 23),
(25, 'B25', 'High', 5, 'no', 50, '2019-07-17 12:01:38', 'Active', 23),
(26, 'B26', 'High', 5, 'no', 50, '2019-07-17 12:01:38', 'Active', 23),
(27, 'B27', 'High', 5, 'no', 50, '2019-07-17 12:01:38', 'Active', 23),
(28, 'B28', 'High', 6, 'no', 100, '2022-04-10 11:27:30', 'Active', 23),
(29, 'B29', 'High', 6, 'no', 100, '2019-07-17 12:01:38', 'Active', 23),
(30, 'B30', 'High', 6, 'no', 100, '2019-08-03 08:52:47', 'InActive', 23),
(31, 'B31', 'High', 6, 'no', 100, '2019-07-27 17:19:29', 'InActive', 23),
(32, 'B32', 'High', 6, 'no', 100, '2019-07-17 12:01:38', 'Active', 23),
(33, 'B33', 'High', 6, 'no', 100, '2019-09-14 11:02:15', 'InActive', 23),
(34, 'B35', 'High', 3, 'NO', 160, '2019-07-28 08:27:04', 'InActive', 23),
(35, 'B36', 'High', 7, 'NO DISCRIPTION', 160, '2019-07-17 12:01:38', 'Active', 23),
(36, 'B37', 'High', 7, 'NO DISCRIPTION', 160, '2019-07-17 12:01:38', 'Active', 23),
(37, 'B38', 'High', 7, 'NO DISCRIPTION', 160, '2019-07-17 12:01:38', 'Active', 23),
(38, 'B39', 'High', 7, 'NO DISCRIPTION', 160, '2019-07-17 12:01:38', 'Active', 23),
(39, 'B40', 'High', 7, 'NO DISCRIPTION', 160, '2019-07-17 12:01:38', 'Active', 23),
(40, '0', 'vib', 10, 'high', 100, '2019-09-18 08:20:23', 'Active', 8),
(41, 'B80', 'VIP', 2, 'vip bed', 100, '2019-09-19 04:45:58', 'Active', 8);

-- --------------------------------------------------------

--
-- Table structure for table `bio_chemestry`
--

CREATE TABLE `bio_chemestry` (
  `Request_lab_id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Patient_name` varchar(50) NOT NULL,
  `Age` varchar(15) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Patient_type` varchar(50) NOT NULL,
  `Doctor_name` varchar(50) NOT NULL,
  `Ticket_id` int(11) NOT NULL,
  `Test_date` date NOT NULL,
  `Glucose` varchar(25) NOT NULL,
  `Greatmine` varchar(25) NOT NULL,
  `Bihurubin_dir` varchar(25) NOT NULL,
  `Cholestereo_tol` varchar(25) NOT NULL,
  `S_G_O_T` varchar(25) NOT NULL,
  `B_urea` varchar(25) NOT NULL,
  `Uric_acid` varchar(25) NOT NULL,
  `Bihurubin_tol` varchar(25) NOT NULL,
  `Total_protein` varchar(25) NOT NULL,
  `S_G_P_T` varchar(25) NOT NULL,
  `Others` varchar(25) NOT NULL,
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bio_chemestry`
--

INSERT INTO `bio_chemestry` (`Request_lab_id`, `Patient_id`, `Patient_name`, `Age`, `Gender`, `Patient_type`, `Doctor_name`, `Ticket_id`, `Test_date`, `Glucose`, `Greatmine`, `Bihurubin_dir`, `Cholestereo_tol`, `S_G_O_T`, `B_urea`, `Uric_acid`, `Bihurubin_tol`, `Total_protein`, `S_G_P_T`, `Others`, `User_name`) VALUES
(2, 8, 'Cimran Nur Ali', '1-15', 'Male', '', '', 3, '2019-07-23', 'g', '2', 'g', 'cholest', 'normal', '2', '3', 'normal', '14', '5', 'others', 'AIsha'),
(3, 7, 'Ruqiyo Ahmed Nur', '37-47', 'Female', '', '', 3, '2019-07-24', 'normal', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', 'AIsha'),
(4, 2, 'Nurto Ali Hasan', '26-36', 'Female', '', 'Ahmed wali', 2, '2019-07-04', 'Normal', 'normal', 'upnormal', 'cholest', '-----', '-----', '-----', '-----', '14', '-----', '-----', 'AIsha'),
(5, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '2019-08-04', 'Normal', 'Normal', 'Normal', 'cholest', 'Normal', '-----', '-----', '-----', '-----', '-----', '-----', 'AIsha'),
(6, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '2019-08-15', 'Normal', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', 'AIsha'),
(7, 4, 'Ahmed Ali Ahmed', '<1', 'Male', 'Inpatient', 'dahir Hashi', 2, '2019-10-08', '13', '-----', '-----', 'cholest', '-----', '-----', '-----', '-----', '-----', '-----', 'no', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `blood_test`
--

CREATE TABLE `blood_test` (
  `Id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Patient_name` varchar(50) NOT NULL,
  `Age` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Test_date` date NOT NULL,
  `Haemoglobin` text NOT NULL,
  `TLC` text NOT NULL,
  `Neutrophils` text NOT NULL,
  `Lymphocytes` text NOT NULL,
  `Eosinophil` text NOT NULL,
  `Monocytes` text NOT NULL,
  `Basophils` text NOT NULL,
  `MCHC` text NOT NULL,
  `MCV` text NOT NULL,
  `MCH` text NOT NULL,
  `Paracytes` text NOT NULL,
  `Blood_grouping` text NOT NULL,
  `Plasma_fibrinogin` text NOT NULL,
  `HIV` text NOT NULL,
  `Others` text NOT NULL,
  `User_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blood_test`
--

INSERT INTO `blood_test` (`Id`, `Patient_id`, `Patient_name`, `Age`, `Gender`, `Test_date`, `Haemoglobin`, `TLC`, `Neutrophils`, `Lymphocytes`, `Eosinophil`, `Monocytes`, `Basophils`, `MCHC`, `MCV`, `MCH`, `Paracytes`, `Blood_grouping`, `Plasma_fibrinogin`, `HIV`, `Others`, `User_id`) VALUES
(1, 2, 'dbdh', '4', 'Male', '2019-03-28', '20', '23', '24', '45', '20', '20', '50', '20', '80', '70', '30', '100', '88', '25', '100', 0);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `Cityid` int(11) NOT NULL,
  `Cityname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`Cityid`, `Cityname`) VALUES
(1, 'Mogadishu'),
(2, 'Sh.hoose'),
(3, 'Sh.dhexe');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `Deptid` int(11) NOT NULL,
  `Deptname` varchar(50) NOT NULL,
  `Description` varchar(250) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`Deptid`, `Deptname`, `Description`, `Status`) VALUES
(1, 'Pharmacist', 'department about pharmacy', 'Active'),
(2, 'Laboratory', 'department about laboratory', 'Inactive'),
(7, 'Pradiatic', 'this is pradiatic', 'Inactive'),
(9, 'Medial', 'deparment about medical', 'Active'),
(10, 'Inpatient service', 'department about inpatient service', 'Active'),
(11, 'Outpatient department', 'department about OPD', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis`
--

CREATE TABLE `diagnosis` (
  `Id` int(11) NOT NULL,
  `Diagnosis_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `diagnosis`
--

INSERT INTO `diagnosis` (`Id`, `Diagnosis_name`) VALUES
(1, 'Malaria'),
(2, 'Typhoid'),
(3, 'Urine'),
(4, 'Stool'),
(5, 'HIV'),
(6, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `disease`
--

CREATE TABLE `disease` (
  `Id` int(11) NOT NULL,
  `Disease` varchar(20) NOT NULL,
  `Creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `User_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `disease`
--

INSERT INTO `disease` (`Id`, `Disease`, `Creation_date`, `User_id`) VALUES
(1, 'Diseases', '2019-05-15 13:02:31', 8),
(2, 'Abdominal pain', '2019-05-15 11:32:07', 8),
(3, 'Abortion', '2019-05-15 11:32:18', 8),
(5, 'Ache vulgasis', '2019-05-15 11:33:13', 8),
(6, 'Amaurosis Fugax', '2019-05-15 11:33:17', 8),
(7, 'Amenerrhoea', '2019-05-15 11:33:22', 8),
(8, 'Anemia', '2019-05-15 11:33:26', 8),
(9, 'Anal imperforation', '2019-05-15 11:33:30', 8),
(10, 'Anxiety disorder', '2019-05-15 11:33:35', 8),
(11, 'Appendicits', '2019-05-15 11:33:44', 8),
(12, 'Arthritis', '2019-05-15 11:33:48', 8),
(13, 'Ascites', '2019-05-15 11:33:52', 8),
(14, 'ASTHMA', '2019-05-15 11:33:58', 8),
(15, 'Back pain', '2019-05-15 11:34:03', 8),
(16, 'Bells pallsy', '2019-05-15 11:35:21', 8),
(17, 'Bleeding', '2019-05-15 11:35:28', 8),
(18, 'Breast carcinoma', '2019-05-15 11:35:32', 8),
(19, 'breast pain', '2019-05-15 11:35:35', 8),
(20, 'Bronchial Asthma', '2019-05-15 11:35:39', 8),
(21, 'Bronchitis', '2019-05-15 11:35:42', 8),
(22, 'burn', '2019-05-15 11:35:48', 8),
(23, 'Caessarian', '2019-05-15 11:35:51', 8),
(24, 'Car accident', '2019-05-15 11:35:55', 8),
(25, 'Cardiopathy', '2019-05-15 11:36:04', 8),
(26, 'Ceflea', '2019-05-15 12:49:29', 8),
(27, 'cerebellar disease', '2019-05-15 12:49:29', 8),
(28, 'Cervical Lymphadenit', '2019-05-15 12:49:29', 8),
(29, 'Cervical Mass', '2019-05-15 12:49:29', 8),
(30, 'Chest Pain', '2019-05-15 12:49:29', 8),
(31, 'Cholycystitis', '2019-05-15 12:49:29', 8),
(32, 'Chorea', '2019-05-15 12:49:29', 8),
(33, 'Chronic Appendicitis', '2019-05-15 12:49:29', 8),
(34, 'Chronic wound', '2019-05-15 12:49:29', 8),
(35, 'Cirrhosis', '2019-05-15 12:49:29', 8),
(36, 'CNS', '2019-05-15 12:49:29', 8),
(37, 'Coma', '2019-05-15 12:49:29', 8),
(38, 'Coma Food Intoxicati', '2019-05-15 12:49:29', 8),
(39, 'Complete Abortion', '2019-05-15 12:49:29', 8),
(41, 'Contralateral Hemipl', '2019-05-15 12:49:29', 8),
(42, 'Ovarian Cyst', '2019-05-15 12:49:29', 8),
(43, 'D & V', '2019-05-15 12:49:29', 8),
(44, 'Deep Venous Thrombos', '2019-05-15 12:49:29', 8),
(45, 'Depressions', '2019-05-15 12:49:29', 8),
(46, 'Dermatitis', '2019-05-15 12:49:29', 8),
(47, 'Diabetes Mellitus', '2019-05-15 12:49:29', 8),
(48, 'Diarrhoea', '2019-05-15 12:49:29', 8),
(49, 'Dimentia', '2019-05-15 12:49:29', 8),
(50, 'Diplegic', '2019-05-15 12:49:29', 8),
(51, 'Discharge', '2019-05-15 12:49:29', 8),
(52, 'Dsymenorrhoea', '2019-05-15 12:49:29', 8),
(53, 'Dysentery', '2019-05-15 12:49:29', 8),
(54, 'Dyspepsia', '2019-05-15 12:49:29', 8),
(55, 'Dysphasia', '2019-05-15 12:49:29', 8),
(56, 'Dyspnoea', '2019-05-15 12:49:29', 8),
(57, 'Dysuria', '2019-05-15 12:49:29', 8),
(58, 'Eclampsia', '2019-05-15 12:49:29', 8),
(59, 'Eczeme Dermalits', '2019-05-15 12:49:29', 8),
(60, 'Emesis Distension', '2019-05-15 12:49:29', 8),
(61, 'Endometritis', '2019-05-15 12:49:29', 8),
(62, 'Epididymitis', '2019-05-15 12:49:29', 8),
(63, 'Epigastric Hernia', '2019-05-15 12:49:29', 8),
(64, 'Epigastric pain', '2019-05-15 12:49:29', 8),
(65, 'Epilepsy', '2019-05-15 12:49:29', 8),
(66, 'Eye Disease', '2019-05-15 12:49:29', 8),
(67, 'Febrile Seizures', '2019-05-15 12:49:29', 8),
(68, 'Fever of Unknown Ori', '2019-05-15 12:49:29', 8),
(69, 'Fistula', '2019-05-15 12:49:29', 8),
(70, 'Flemony', '2019-05-15 12:49:29', 8),
(71, 'Food Intoxication', '2019-05-15 12:49:29', 8),
(72, 'Full Term Delivery', '2019-05-15 12:49:29', 8),
(73, 'Full Term Pregnancy', '2019-05-15 12:49:29', 8),
(74, 'Fungus', '2019-05-15 12:49:29', 8),
(75, 'fx or #', '2019-05-15 12:49:29', 8),
(76, 'Gastritis', '2019-05-15 12:49:29', 8),
(77, 'Gastroenteritis', '2019-05-15 12:49:29', 8),
(78, 'Gestahomalage', '2019-05-15 12:49:29', 8),
(79, 'Goitre', '2019-05-15 12:49:29', 8),
(80, 'gonorrhoea', '2019-05-15 12:49:29', 8),
(81, 'Gonorrhea', '2019-05-15 12:49:29', 8),
(82, 'HIV', '2019-05-15 12:49:29', 8),
(83, 'Haematomasis', '2019-05-15 12:49:29', 8),
(84, 'Headache ', '2019-05-15 12:49:29', 8),
(85, 'Hemiplegia', '2019-05-15 12:49:29', 8),
(86, 'Hemiplegic', '2019-05-15 12:49:29', 8),
(87, 'Hemophilia', '2019-05-15 12:49:29', 8),
(88, 'Henfreial', '2019-05-15 12:49:29', 8),
(89, 'Amoebic liver diseas', '2019-05-15 12:49:29', 8),
(90, 'Hepatitis (B)', '2019-05-15 12:49:29', 8),
(91, 'Hernia', '2019-05-15 12:49:29', 8),
(92, 'Hydrocele', '2019-05-15 12:49:29', 8),
(93, 'Hypertension', '2019-05-15 12:49:29', 8),
(94, 'Hypoglycemia', '2019-05-15 12:49:29', 8),
(95, 'Hypospadia', '2019-05-15 12:49:29', 8),
(96, 'Hypotension', '2019-05-15 12:49:29', 8),
(97, 'I.U.F.D', '2019-05-15 12:49:29', 8),
(98, 'Idiopathia Seizmes', '2019-05-15 12:49:29', 8),
(99, 'Incomplete abortion', '2019-05-15 12:49:29', 8),
(100, 'Infection', '2019-05-15 12:49:29', 8),
(101, 'Infertility', '2019-05-15 12:49:29', 8),
(102, 'Inguinal Hernia', '2019-05-15 12:49:29', 8),
(103, 'Insomnia', '2019-05-15 12:49:29', 8),
(104, 'Ipsilateral Hemipleg', '2019-05-15 12:49:29', 8),
(105, 'Itching', '2019-05-15 12:49:29', 8),
(106, 'Jaundice', '2019-05-15 12:49:29', 8),
(107, 'Kidneys Pain', '2019-05-15 12:49:29', 8),
(108, 'Laceretion', '2019-05-15 12:49:29', 8),
(109, 'Lactation', '2019-05-15 12:49:29', 8),
(110, 'Left Loin Pain', '2019-05-15 12:49:29', 8),
(111, 'Lipoma', '2019-05-15 12:49:29', 8),
(112, 'Liver Disease', '2019-05-15 12:49:29', 8),
(113, 'Loins pain', '2019-05-15 12:49:29', 8),
(114, 'Loss Appetite', '2019-05-15 12:49:29', 8),
(115, 'Lower Abdominal pain', '2019-05-15 12:49:29', 8),
(116, 'LRTI', '2019-05-15 12:49:29', 8),
(117, 'Lumabgo', '2019-05-15 12:49:29', 8),
(118, 'Lymph Adenitis', '2019-05-15 12:49:29', 8),
(119, 'Malaria', '2019-05-15 12:49:29', 8),
(120, 'Malnutrition', '2019-05-15 12:49:29', 8),
(121, 'Mandibular Abscess', '2019-05-15 12:49:29', 8),
(122, 'Mastitis', '2019-05-15 12:49:29', 8),
(123, 'MEASELS', '2019-05-15 12:49:29', 8),
(124, 'Migraine', '2019-05-15 12:49:29', 8),
(125, 'Mioma uterus', '2019-05-15 12:49:29', 8),
(126, 'Missed Abortion', '2019-05-15 12:49:29', 8),
(127, 'Molo Fascicular', '2019-05-15 12:49:29', 8),
(128, 'Mono Reupathy ', '2019-05-15 12:49:29', 8),
(129, 'monoplegic', '2019-05-15 12:49:29', 8),
(130, 'Narcolepsi', '2019-05-15 12:49:29', 8),
(131, 'Nauriti', '2019-05-15 12:49:29', 8),
(132, 'Neuropathic Pain', '2019-05-15 12:49:29', 8),
(133, 'Nudula of the ear', '2019-05-15 12:49:29', 8),
(134, 'oligomenorrhoea', '2019-05-15 12:49:29', 8),
(135, 'Omphalitis', '2019-05-15 12:49:29', 8),
(136, 'Orchitis', '2019-05-15 12:49:29', 8),
(137, 'Osteoprosis', '2019-05-15 12:49:29', 8),
(138, 'Otitis Externa', '2019-05-15 12:49:29', 8),
(139, 'Otitis Media', '2019-05-15 12:49:29', 8),
(140, 'Pain anas', '2019-05-15 12:49:29', 8),
(141, 'Pain in..', '2019-05-15 12:49:29', 8),
(142, 'Pain scapular', '2019-05-15 12:49:29', 8),
(143, 'paraesteria rt exter', '2019-05-15 12:49:29', 8),
(144, 'paraplegic', '2019-05-15 12:49:29', 8),
(145, 'Parasite', '2019-05-15 12:49:29', 8),
(146, 'Pelvic pain', '2019-05-15 12:49:29', 8),
(147, 'Parkinson Disease', '2019-05-15 12:49:29', 8),
(148, 'Pharyngitis', '2019-05-15 12:49:29', 8),
(149, 'ployurea', '2019-05-15 12:49:29', 8),
(150, 'Pneumonia', '2019-05-15 12:49:29', 8),
(151, 'DM 2', '2019-05-15 12:49:29', 8),
(152, 'Post  partum infecti', '2019-05-15 12:49:29', 8),
(153, 'Post Partum Anemia', '2019-05-15 12:49:29', 8),
(154, 'post partum Hemorrha', '2019-05-15 12:49:29', 8),
(155, 'post partum infectio', '2019-05-15 12:49:29', 8),
(156, 'PPH', '2019-05-15 12:49:29', 8),
(157, 'Pre-eclampsia', '2019-05-15 12:49:29', 8),
(158, 'Premature Labour', '2019-05-15 12:49:29', 8),
(159, 'psoariasis', '2019-05-15 12:49:29', 8),
(160, 'Psychosis', '2019-05-15 12:49:29', 8),
(161, 'Quadraplegic', '2019-05-15 12:49:29', 8),
(162, 'Renal Colic', '2019-05-15 12:49:29', 8),
(163, 'Glomerulonephritis', '2019-05-15 12:49:29', 8),
(164, 'Renal artery Stenosi', '2019-05-15 12:49:29', 8),
(165, 'GERD', '2019-05-15 12:49:29', 8),
(166, 'PID', '2019-05-15 12:49:29', 8),
(167, 'Right loin pain', '2019-05-15 12:49:29', 8),
(168, 'S.headache', '2019-05-15 12:49:29', 8),
(169, 'Scabies', '2019-05-15 12:49:29', 8),
(170, 'schizophrenie', '2019-05-15 12:49:29', 8),
(171, 'seizures', '2019-05-15 12:49:29', 8),
(172, 'shock', '2019-05-15 12:49:29', 8),
(173, 'Sinusitis', '2019-05-15 12:49:29', 8),
(174, 'Skin Disease', '2019-05-15 12:49:29', 8),
(175, 'Stomatitis', '2019-05-15 12:49:29', 8),
(176, 'Syncope', '2019-05-15 12:49:29', 8),
(177, 'Threatened abortion', '2019-05-15 12:49:29', 8),
(178, 'Tonsilitis', '2019-05-15 12:49:29', 8),
(179, 'Torticollis ', '2019-05-15 12:49:29', 8),
(180, 'Trauma', '2019-05-15 12:49:29', 8),
(181, 'Triplegic', '2019-05-15 12:49:29', 8),
(182, 'ulcer', '2019-05-15 12:49:29', 8),
(183, 'Oral Ulcers', '2019-05-15 12:49:29', 8),
(184, 'Umbilical Hernia', '2019-05-15 12:49:29', 8),
(185, 'urinary retention', '2019-05-15 12:49:29', 8),
(186, 'Urethritis', '2019-05-15 12:49:29', 8),
(187, 'URTI', '2019-05-15 12:49:29', 8),
(188, 'Urticaria', '2019-05-15 12:49:29', 8),
(189, 'UTI', '2019-05-15 12:49:29', 8),
(190, 'UTR', '2019-05-15 12:49:29', 8),
(191, 'Vaginal Bleeding', '2019-05-15 12:49:29', 8),
(192, 'Vague Body Pain', '2019-05-15 12:49:29', 8),
(193, 'Varicose veins', '2019-05-15 12:49:29', 8),
(194, 'Vertigo', '2019-05-15 12:49:29', 8),
(195, 'vomiting', '2019-05-15 12:49:29', 8),
(196, 'Whooping cough', '2019-05-15 12:49:29', 8),
(197, 'Renal Calculi', '2019-05-15 12:49:29', 8),
(198, 'Gout', '2019-05-15 12:49:29', 8),
(199, 'None', '2019-05-15 12:49:29', 8),
(200, 'Glossitis', '2019-05-15 12:49:29', 8),
(201, 'congenital deafness', '2019-05-15 12:49:29', 8),
(202, 'Hepatocellular carci', '2019-05-15 12:49:29', 8),
(204, 'trouma', '2019-05-15 12:49:29', 8),
(205, 'Gallstone', '2019-05-15 12:49:29', 8),
(206, 'BPH', '2019-05-15 12:49:29', 8),
(207, 'Osteomyelitis', '2019-05-15 12:49:29', 8),
(208, 'Peptic Ulcer Disease', '2019-05-15 12:49:29', 8),
(209, 'pelvic inflamotory d', '2019-05-15 12:49:29', 8),
(210, 'Pregnancy', '2019-05-15 12:49:29', 8),
(211, 'Routine Medical Chec', '2019-05-15 12:49:29', 8),
(212, 'chronic constipation', '2019-05-15 12:49:29', 8),
(213, 'short stature', '2019-05-15 12:49:29', 8),
(214, 'Antenatal Care', '2019-05-15 12:49:29', 8),
(215, 'Barret Esophagus', '2019-05-15 12:49:29', 8),
(216, 'Diverticulosis', '2019-05-15 12:49:29', 8),
(217, 'Rheumatoid Arthritis', '2019-05-15 12:49:29', 8),
(218, 'Dizziness', '2019-05-15 12:49:29', 8),
(219, 'Hepatitis (C) ', '2019-05-15 12:49:29', 8),
(220, 'DM 1', '2019-05-15 12:49:29', 8),
(221, 'Uterine Lieomyoma', '2019-05-15 12:49:29', 8),
(222, 'Sterility', '2019-05-15 12:49:29', 8),
(223, 'Oral Candidiasis', '2019-05-15 12:49:29', 8),
(224, 'anc', '2019-05-15 12:49:29', 8),
(225, 'Anaphylaxis', '2019-05-15 12:49:29', 8),
(226, 'Skull Fracture', '2019-05-15 12:49:29', 8),
(227, 'Skin Infection', '2019-05-15 12:49:29', 8),
(228, 'Heart Block', '2019-05-15 12:49:29', 8),
(229, 'bronchopneumonia', '2019-05-15 12:49:29', 8),
(230, 'AFP', '2019-05-15 12:49:29', 8),
(231, 'pyloric stenosis', '2019-05-15 12:49:29', 8),
(232, 'postmeasles complica', '2019-05-15 12:49:29', 8),
(233, 'anorexia', '2019-05-15 12:49:29', 8),
(234, 'anemia(severe)', '2019-05-15 12:49:29', 8),
(235, 'anemia(mild)', '2019-05-15 12:49:29', 8),
(236, 'anemia(moderate)', '2019-05-15 12:49:29', 8),
(237, 'false labour ', '2019-05-15 12:49:29', 8),
(238, 'cortem', '2019-05-15 12:49:29', 8),
(239, 'Ganglion Cyst', '2019-05-15 12:49:29', 8),
(240, 'Bladder rupture', '2019-05-15 12:49:29', 8),
(241, 'CBD Stone', '2019-05-15 12:49:29', 8),
(242, 'Herpes Zoster', '2019-05-15 12:49:29', 8),
(243, 'Hypercholesterolemia', '2019-05-15 12:49:29', 8),
(244, 'Perforated Tympanic ', '2019-05-15 12:49:29', 8),
(245, 'Chronic Liver Diseas', '2019-05-15 12:49:29', 8),
(246, 'labour', '2019-05-15 12:49:29', 8),
(247, 'hyperthyroidism', '2019-05-15 12:49:29', 8),
(248, 'UB stone', '2019-05-15 12:49:29', 8),
(249, 'deabtic', '2019-05-15 12:49:29', 8),
(250, 'CHF', '2019-05-15 12:49:29', 8),
(251, 'secondry Infertility', '2019-05-15 12:49:29', 8),
(252, 'fracture', '2019-05-15 12:49:29', 8),
(253, 'thretend abortion ', '2019-05-15 12:49:29', 8),
(254, 'inafetable abortion', '2019-05-15 12:49:29', 8),
(255, 'DVT', '2019-05-15 12:49:29', 8),
(256, 'eczema', '2019-05-15 12:49:29', 8);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `Id` int(11) NOT NULL,
  `Fullname` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Designation` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Department_id` int(11) NOT NULL,
  `City` varchar(25) NOT NULL,
  `Address` varchar(80) NOT NULL,
  `Specialist` varchar(30) NOT NULL,
  `Rate` int(11) NOT NULL,
  `Tell` int(11) NOT NULL,
  `Room_No` int(11) NOT NULL,
  `Picture` varchar(150) NOT NULL,
  `Shortbiography` varchar(500) NOT NULL,
  `Age` varchar(20) NOT NULL,
  `Bloodgroup` varchar(10) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `User_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`Id`, `Fullname`, `Email`, `Designation`, `Department`, `Department_id`, `City`, `Address`, `Specialist`, `Rate`, `Tell`, `Room_No`, `Picture`, `Shortbiography`, `Age`, `Bloodgroup`, `Gender`, `Status`, `User_name`) VALUES
(1, 'Dhaqane Ali', 'dhaqane@gmail.com', 'title', '7', 2, 'Mogadishu', 'Wadajir', 'Kidney', 1, 55445454, 1, 'img', 'hdhjsdh', '50', 'A+', 'male', 'Active', '1'),
(4, 'saaa', 's@gmail.com', 'title', '7', 7, 'Mogadishu', 'Wadajir', 'Kidney', 1, 5665656, 4, 'img', 'jshhs', '50', 'A+', 'Male', 'Inactive', '1'),
(7, 'Ismahn', 'Moha6@gmail.com', 'title', '8', 1, 'Mogadishu', 'Wadajir', 'Neurology', 1, 2147483647, 1, 'Docimg/d2.png', 'wyd4dvfbtgyunk.p\'o', '1-15', 'A+', 'Male', 'Active', '8'),
(8, 'Sayid Ahmed', 'sayid@gmail.com', 'title', '8', 7, 'Mogadishu', 'Dharkenley', 'Eye', 1, 2147483647, 4, 'Docimg/ju200305.jpg', 'djndndnk', '59-69', 'A+', 'Male', 'Active', '11'),
(9, 'Ahmed Hashi', 'abdi@gmial.com', 'Almas', '8', 17, '8', 'Mogadishu', 'Waaberi', 1, 615522335, 1, '4', 'Docimg/989.jpg', 'gfghfhkff', '48-58', 'O+', '', '0'),
(10, 'Sayidka', 'sayid@gmial.com', 'Almas', '8', 17, '2', 'Mogadishu', 'Boondheere', 1, 615228899, 1, '6', 'Docimg/Abka.png', 'the best', '48-58', 'O+', 'Active', '0'),
(11, 'Geedi', 'ded@gmail.com', 'Top', '8', 4, 'mogadisho', 'hodan', 'noise', 1, 788786, 2, 'imj.jpg', 'best', '32', 'O+', 'male', '', '2'),
(12, 'Ahmed wali', 'Axmedwali@gmial.com', 'Almas', '7', 7, '2', 'Mogadishu', 'Ear,Nose,Throat(ENT)', 1, 615522110, 2, '5', 'Docimg/', 'best', '37-47', 'O+', 'Inactive', '0'),
(13, 'dahir Hashi', 'dahir@gmail.com', 'Almas', '8', 1, 'Mogadishu', 'Dharkenley', 'Neurology', 1, 89798798, 4, 'Docimg/989.jpg', 'best', '59-69', 'O+', 'Male', '', '0'),
(14, 'ali musa', 'alimusa@gmial.com', 'top', '8', 7, 'Mogadishu', 'Xamar weyne', 'Ear,Nose,Throat(ENT)', 1, 61552233, 61552233, 'Docimg/14 Oct.jpg', 'best', '48-58', 'AB+', 'Male', 'Active', '0'),
(15, 'farah ali', 'farah@gmail.com', 'top', 'pharmacist', 1, 'Mogadishu', 'Wadajir', 'Ear,Nose,Throat(ENT)', 1, 89798798, 89798798, 'Docimg/989.jpg', 'the best', '59-69', 'B+', 'Male', 'Active', '17'),
(16, 'Sayidka ali', 'as@gmial.com', 'top', '8', 1, 'Mogadishu', 'Yaaqshiid', 'Ear,Nose,Throat(ENT)', 1, 89798798, 5, 'Docimg/989.jpg', 'besg', '70-80', 'B-', 'Male', 'Active', '17'),
(18, 'ali mohamed', 'alif@gmial.com', 'Almas', '7', 7, 'Mogadishu', 'Boondheere', 'Eye', 1, 89798798, 6, 'Docimg/989.jpg', '', '37-47', 'B-', 'Male', 'Active', '17'),
(20, 'Ummi', 'ummi@gmail.com', 'title', '1', 1, 'Mogadishu', 'Wadajir', 'Neurology', 1, 56565655, 6, 'Docimg/d3.png', 'ghhhihihij', '26-36', 'A+', 'Female', 'Active', '8'),
(21, 'Haji', 'haji@gmail.com', 'title', '2', 2, 'Mogadishu', 'Waaberi', 'Ear,Nose,Throat(ENT)', 1, 615889966, 3, 'Docimg/d3.png', 'lkk;kl;pl', '<1', 'A+', 'Male', 'Active', '8'),
(22, 'Luul Hasan Ali', 'luul2019@gmail.com', 'doctor', '7', 7, 'Mogadishu', 'Dayniile', 'Neurology', 1, 61552233, 2, 'Docimg/bannel.jpg', 'waa doctor', '37-47', 'AB-', 'Female', 'Active', '8'),
(23, 'Luul Hasan Ali', 'luulo2019@gmail.com', 'doctor', '7', 7, 'Mogadishu', 'Dayniile', 'Neurology', 1, 61552233, 2, 'Docimg/bannel.jpg', 'waa doctor', '37-47', 'AB-', 'Female', 'Active', '8'),
(24, 'Qalid Ali Hasan', 'qalid@gmail.com', 'doctor', '2', 2, 'Mogadishu', 'Dharkenley', 'Neurology', 1, 61555555, 3, 'Docimg/bannel.jpg', 'waa lab', '16-25', 'AB-', 'Male', 'Active', '8'),
(25, 'saa', 'ddd@gmail.com', 'doctor', 'Pradiatic', 7, 'Mogadishu', 'hodan', 'Neurology', 1, 1555555, 1, 'Docimg/bannel.jpg', 'wwwwwwww', '<1', 'A+', 'Male', 'Active', '8'),
(26, 'Yasir Ali Mohamed', 'yasir@gmail.com', 'doctor', 'Laboratory', 2, 'Mogadishu', 'waaberi', 'Neurology', 1, 615522336, 1, 'Docimg/bannel.jpg', 'this is the his', '37-47', 'A+', 'Male', 'Active', '8'),
(27, 'Feysal Ali Ahmed', 'feysal@gmail.com', 'doctor', 'Laboratory', 2, 'Mogadishu', 'Dharkenley', 'Ear,Nose,Throat(ENT)', 1, 615223366, 1, 'Docimg/d2.png', 'waa dhaqtar taq', '48-58', 'AB+', 'Male', 'Active', '8');

-- --------------------------------------------------------

--
-- Table structure for table `druggroup`
--

CREATE TABLE `druggroup` (
  `Id` int(11) NOT NULL,
  `Drug_group` varchar(50) NOT NULL,
  `Creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `druggroup`
--

INSERT INTO `druggroup` (`Id`, `Drug_group`, `Creation_date`, `User_name`) VALUES
(1, 'Group2', '2019-09-18 17:26:03', '1'),
(2, 'Group1', '2019-09-18 17:25:45', '8'),
(3, 'Sodium', '2019-07-10 17:27:41', '8'),
(4, 'aaaaa', '2022-04-10 11:17:21', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `drugs`
--

CREATE TABLE `drugs` (
  `Id` int(11) NOT NULL,
  `Drug_name_id` int(11) NOT NULL,
  `Drug_name` varchar(50) NOT NULL,
  `Drug_type` varchar(600) NOT NULL,
  `Drug_group` varchar(100) NOT NULL,
  `Price` float NOT NULL,
  `Company` varchar(100) NOT NULL,
  `Expired_date` date NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `drugs`
--

INSERT INTO `drugs` (`Id`, `Drug_name_id`, `Drug_name`, `Drug_type`, `Drug_group`, `Price`, `Company`, `Expired_date`, `Quantity`, `Creation_date`, `User_name`) VALUES
(5, 1, 'Tablet', 'Coltab', 'samples', 3, 'kamel', '2019-08-08', 50, '2019-08-08 11:32:59', 'AIsha'),
(7, 2, 'Syrup', 'Vitamin A complex', 'samples', 6, 'kamel', '2019-08-08', 44, '2019-09-18 18:21:12', 'AIsha'),
(8, 2, 'Syrup', 'Vitamin B complex', 'Group1', 1, 'Jamjoom', '2019-09-18', 96, '2019-09-18 18:21:12', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `drugtype`
--

CREATE TABLE `drugtype` (
  `Id` int(11) NOT NULL,
  `Drug_type` varchar(50) NOT NULL,
  `Creation_date` date NOT NULL,
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `drugtype`
--

INSERT INTO `drugtype` (`Id`, `Drug_type`, `Creation_date`, `User_name`) VALUES
(1, 'Bracetemol', '2019-08-08', 'AIsha'),
(2, 'Coltab', '2019-08-08', 'AIsha'),
(3, 'Tekmol', '2019-08-08', 'AIsha'),
(5, 'Amoxycare', '2019-08-08', 'AIsha'),
(6, 'Vitamin A complex', '2019-08-08', 'AIsha'),
(7, 'Vitamin B complex', '2019-08-08', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Id` int(11) NOT NULL,
  `Fullname` varchar(200) NOT NULL,
  `Email` varchar(800) NOT NULL,
  `Mobile` int(11) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Picture` varchar(1300) NOT NULL,
  `Birth_day` date NOT NULL,
  `Hire_date` date NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Salary` double NOT NULL,
  `Status` varchar(100) NOT NULL,
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Id`, `Fullname`, `Email`, `Mobile`, `Address`, `Gender`, `Picture`, `Birth_day`, `Hire_date`, `Department`, `Salary`, `Status`, `User_name`) VALUES
(1, 'Suldan Ali Mphamed', 'suldan@gmail.com', 615223366, '    Wdadajir                                 ', 'Male', 'Img/bannel.jpg', '2019-08-04', '2019-08-06', 'HRM', 200, 'Active', 'AIsha'),
(2, 'Suldan Ali Mphamed', 'suldan@gmail.com', 615223366, '    Wdadajir                                 ', 'Male', 'Img/bannel.jpg', '2019-08-04', '2019-08-06', 'HRM', 200, '', 'AIsha'),
(3, 'Hibo Nur Ali', 'Hibo144@gmail.com', 61552233, '                  Waaberi          ', 'Female', 'empimg/bannel.jpg', '2019-09-19', '2019-09-06', 'Finance', 400, 'Active', 'AIsha'),
(4, 'Deko Yusuf Ali', 'deko1144@gmail.com', 61552233, 'wadajir                                     ', 'Male', 'empimg/bannel.jpg', '1996-05-13', '2019-09-18', 'Pharmacy', 100, 'Active', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `haematology`
--

CREATE TABLE `haematology` (
  `Request_lab_id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Age` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Patient_type` varchar(50) NOT NULL,
  `Doctor_name` varchar(100) NOT NULL,
  `Ticket_id` int(11) NOT NULL,
  `Test_date` date NOT NULL,
  `HB` varchar(20) NOT NULL,
  `Hematocrit` varchar(20) NOT NULL,
  `RBC` varchar(20) NOT NULL,
  `WBC` varchar(20) NOT NULL,
  `Plateleto` varchar(20) NOT NULL,
  `MCV` varchar(20) NOT NULL,
  `MCH` varchar(20) NOT NULL,
  `MCHC` varchar(20) NOT NULL,
  `Neutrophils` varchar(20) NOT NULL,
  `Eosinophils` varchar(20) NOT NULL,
  `Basophils` varchar(20) NOT NULL,
  `Lymphocytes` varchar(20) NOT NULL,
  `Monocytes` varchar(20) NOT NULL,
  `ESR` varchar(25) NOT NULL,
  `Malaria` varchar(20) NOT NULL,
  `Blood_grouping` varchar(20) NOT NULL,
  `Others` varchar(50) NOT NULL,
  `User_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `haematology`
--

INSERT INTO `haematology` (`Request_lab_id`, `Patient_id`, `Name`, `Age`, `Gender`, `Patient_type`, `Doctor_name`, `Ticket_id`, `Test_date`, `HB`, `Hematocrit`, `RBC`, `WBC`, `Plateleto`, `MCV`, `MCH`, `MCHC`, `Neutrophils`, `Eosinophils`, `Basophils`, `Lymphocytes`, `Monocytes`, `ESR`, `Malaria`, `Blood_grouping`, `Others`, `User_name`) VALUES
(1, 0, 'Ahmed Ali Ahmed', '', '', '', '', 0, '2019-08-05', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'AIsha'),
(2, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', 'OutPatient', 'Ummi', 5, '2019-08-15', '14', '-----', '-----,', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '----', '-----', '----', '-----', '-----', 'AIsha'),
(3, 4, 'Ahmed Ali Ahmed', '<1', 'Male', 'Inpatient', 'dahir Hashi', 2, '2019-08-17', '14', '-----', '-----,', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '----', '-----', 'Positive', '-----', '-----', 'AIsha'),
(4, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '2019-11-20', '-----', '-----', '-----,', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '----', '-----', '----', '-----', '-----', 'AIsha'),
(5, 9, 'Said Ali Hassan', '16-25', 'Male', 'OutPatient', 'Sayid Ahmed', 1, '2019-09-18', '-----', '-----', '-----,', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '----', '-----', 'positive', '-----', '-----', 'AIsha'),
(6, 11, 'Yusro Mohamed  Ali', '16-25', 'Female', 'OutPatient', 'Ummi', 2, '2019-09-19', '-----', '-----', '-----,', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '----', '-----', 'positive', '-----', '-----', 'AIsha'),
(7, 4, 'Ahmed Ali Ahmed', '<1', 'Male', 'Inpatient', 'dahir Hashi', 2, '2019-10-08', '-----', '-----', '-----,', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '----', '-----', 'positive', '-----', 'no', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Address` varchar(25) NOT NULL,
  `Deleted` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `Name`, `Gender`, `Email`, `Phone`, `Address`, `Deleted`) VALUES
(1, '   Ismahan', 'Male', '   ismahan@gmail.com', '   665655', '       Wadajir', 0),
(2, 'Halyelo ', ' Male', ' hal@gmail.com', ' 5666652', ' Hodan', 1),
(3, '  Ismahan', '  Females', '  ismahan@gmail.com', '  665655', 'waaberi', 0);

-- --------------------------------------------------------

--
-- Table structure for table `info2`
--

CREATE TABLE `info2` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info2`
--

INSERT INTO `info2` (`Id`, `Name`, `Gender`, `Email`, `Phone`, `Address`) VALUES
(1, '  Ismahan', '3', '  ismahan@gmail.com', '  665655', '      Wadajir'),
(3, '   Ismahan', 'Other', '   ismahan@gmail.com', '   665655', ' waaberi'),
(1, '  Ismahan', 'Female', '  ismahan@gmail.com', '  665655', '      Wadajir'),
(4, 'Yusuf ', 'Male', ' yu@gmail.com', ' 226262', ' Dharkenley');

-- --------------------------------------------------------

--
-- Table structure for table `intake`
--

CREATE TABLE `intake` (
  `id` int(11) NOT NULL,
  `ipno` varchar(50) DEFAULT NULL,
  `doctor_name` int(50) DEFAULT NULL,
  `department` int(50) DEFAULT NULL,
  `age` varchar(50) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `pdate` varchar(50) DEFAULT NULL,
  `ptime` varchar(50) DEFAULT NULL,
  `oral` varchar(50) DEFAULT NULL,
  `ivi` varchar(50) DEFAULT NULL,
  `urine` varchar(50) DEFAULT NULL,
  `drain` varchar(50) DEFAULT NULL,
  `temp` varchar(50) DEFAULT NULL,
  `pulse` varchar(50) DEFAULT NULL,
  `po` varchar(50) DEFAULT NULL,
  `bp` varchar(50) DEFAULT NULL,
  `res` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `intake`
--

INSERT INTO `intake` (`id`, `ipno`, `doctor_name`, `department`, `age`, `sex`, `pdate`, `ptime`, `oral`, `ivi`, `urine`, `drain`, `temp`, `pulse`, `po`, `bp`, `res`) VALUES
(1, '1', 1, 7, '54', 'male', '2022-04-16', 'gggggg', 'sdsd', 'sds', 'kadi', 'dhahd', '676c', 'sss', 'ss', 'sss', 's');

-- --------------------------------------------------------

--
-- Table structure for table `in_appointment`
--

CREATE TABLE `in_appointment` (
  `Id` int(11) NOT NULL,
  `Patient_name` varchar(50) NOT NULL,
  `Tell` varchar(600) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Department_name` varchar(50) NOT NULL,
  `Doctor_name` varchar(50) NOT NULL,
  `Appointment_date_time` date NOT NULL,
  `Ticket_No` int(11) NOT NULL,
  `Problem` varchar(200) NOT NULL,
  `Status` varchar(15) NOT NULL,
  `Canceled` varchar(600) NOT NULL,
  `User_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `in_appointment`
--

INSERT INTO `in_appointment` (`Id`, `Patient_name`, `Tell`, `Email`, `Department_name`, `Doctor_name`, `Appointment_date_time`, `Ticket_No`, `Problem`, `Status`, `Canceled`, `User_id`) VALUES
(1, 'Sacdiyo Abbas mahdi', '61552233', 'sac2@gmail.com', '2', 'Dhaqane Ali', '2019-09-07', 0, '  xanuun baan ka cawnayaa ee waxaan rabay in aa la balamo doctorka ugu fiican                                   ', 'Active', 'No', 0),
(2, 'Hussein Ali Hasan', '615522332', 'huxsein@gmail.com', '1', 'Ummi', '2019-09-07', 0, '  xanuun baan ka cawnayaa ee waxaan rabay in aa la balamo doctorka ugu fiican                                   ', 'Inactive', 'No', 0),
(3, 'Suheyb Abdirashid Hassan', '61552233', 'suheyb@hotmail.com', '2', 'Qalid Ali Hasan', '2019-09-25', 0, '   dhibaato xaga madax habeenkii                               ', 'Active', 'No', 0),
(4, 'Saalim Ali', '2147483647', 'Saalim@hotmail.com', '2', 'Qalid Ali Hasan', '2019-09-21', 0, '                   hergab                  ', 'Active', 'No', 0),
(5, 'Fartun Sharif Isak', '615223366', 'fartun1@gmail.com', '2', 'Dhaqane Ali', '2019-09-19', 0, '  dhibaato xaga dhabarkka ah                                   ', 'Active', 'No', 0),
(6, 'Fartun Yaxye Ali', '61552233', 'fartunyaxye@gmail.com', '2', 'Feysal Ali Ahmed', '2019-09-19', 0, 'waan dhibanahay                                     ', 'InActive', 'No', 0),
(7, 'Abdi Ali Hassan', '61552230', 'abdi12@gmail.com', '1', 'Ummi', '2019-09-19', 0, 'waan dhibanahay                                     ', 'Active', 'No', 0),
(8, 'Hassan Ali Ahmed', '615223366', 'hassan@gmail.com', '1', 'Ummi', '2019-09-19', 0, '      dhibaato xaga madax ah                               ', 'Active', 'No', 0),
(9, 'mohamed abdi', '616237048', 'mohamad24hours@gmail.com', '7', 'Luul Hasan Ali', '2022-03-03', 0, '                                     ASDFGHJK', 'Active', 'No', 8);

-- --------------------------------------------------------

--
-- Table structure for table `in_patient`
--

CREATE TABLE `in_patient` (
  `Id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Fullname` varchar(50) NOT NULL,
  `Doctor` varchar(50) NOT NULL,
  `Room_No` int(11) NOT NULL,
  `Bed_No` varchar(50) NOT NULL,
  `Bed_cost` double NOT NULL,
  `Reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Orders` varchar(200) NOT NULL,
  `Operation` varchar(10) NOT NULL,
  `Operation_type` varchar(50) NOT NULL,
  `Cost` float NOT NULL,
  `P_U_operation` varchar(25) NOT NULL,
  `Rate` double NOT NULL,
  `User_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `in_patient`
--

INSERT INTO `in_patient` (`Id`, `Patient_id`, `Fullname`, `Doctor`, `Room_No`, `Bed_No`, `Bed_cost`, `Reg_date`, `Orders`, `Operation`, `Operation_type`, `Cost`, `P_U_operation`, `Rate`, `User_name`) VALUES
(1, 6, 'Mohamed Abdi Risak', 'Haji', 1, 'B8', 20, '2019-09-16 21:00:00', 'waa aqliin                                     ', 'Yes', 'Dilation and curretage', 25, 'Paid', 20, 'AIsha'),
(2, 15, 'mohamed abdi', 'Sayidka ali', 6, 'B28', 0, '2022-04-09 21:00:00', '                                     sdafddsdasdadadadads', 'Yes', 'Cataract surgery', 780, 'Paid', 1, 'AIsha');

--
-- Triggers `in_patient`
--
DELIMITER $$
CREATE TRIGGER `update beds` AFTER INSERT ON `in_patient` FOR EACH ROW UPDATE beds SET Status = 'InActive' WHERE Bed_No = NEW.Bed_No
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `laboratoristreg`
--

CREATE TABLE `laboratoristreg` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Tell` varchar(25) NOT NULL,
  `Picture` varchar(200) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `User_name` varchar(25) NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `laboratoristreg`
--

INSERT INTO `laboratoristreg` (`Id`, `Name`, `Email`, `Address`, `Tell`, `Picture`, `Gender`, `Creation_date`, `User_name`, `Status`) VALUES
(2, 'Asi Yusuf Ali', 'Asi@gail.com', 'Hodan', '2262623263', 'Labimg/w3.png', 'Female', '2019-08-28 11:12:29', 'AIsha', 'InActive'),
(3, 'Fahad Abbas Ali', 'fahad@gmsil.com', 'Yaaqshiid', '061552233', 'Labimg/d2.png', 'Male', '2019-09-18 18:02:56', 'AIsha', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `nurses`
--

CREATE TABLE `nurses` (
  `Id` int(11) NOT NULL,
  `Fullname` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Tell` varchar(50) NOT NULL,
  `Picture` varchar(200) NOT NULL,
  `Doctor_name` varchar(50) NOT NULL,
  `Gender` varchar(15) NOT NULL,
  `Creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `User_name` varchar(25) NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nurses`
--

INSERT INTO `nurses` (`Id`, `Fullname`, `Username`, `Password`, `Email`, `Address`, `Tell`, `Picture`, `Doctor_name`, `Gender`, `Creation_date`, `User_name`, `Status`) VALUES
(1, 'Shadiyo Ali', 'Shadiyo', '8877691d24773f3cb0239ef411e35b71', 'Shad@gmail.com', 'Wadajir', '061552233', 'img', 'Sayid Ahmed', 'Female', '2019-09-18 17:40:06', 'AIsha', 'Active'),
(2, 'Mohamed Ali Mohamed', 'moha', '8877691d24773f3cb0239ef411e35b71', 'Moha1@gmail.com', 'Dharkenley', '0255555555', 'Img/user2-160x160.png', 'dahir Hashi', 'Male', '2019-09-18 17:46:42', 'AIsha', 'Inactive'),
(3, 'sacdiyo Abbas Mahdi', 'sacdiyo', '8877691d24773f3cb0239ef411e35b71', 'sacdiyo@hotmail.com', 'Xamarjajab', '02123232', 'Nurseimg/ju200301 (1).jpg', 'Ahmed wali', 'Female', '2019-09-18 17:41:21', 'AIsha', 'Active'),
(4, 'Ruqiyo Ahmed Nur', 'ruqiyo', '8877691d24773f3cb0239ef411e35b71', 'ruq@gmail.com', 'Dayniile', '562626262', 'Nurseimg/w1.png', 'Faadumiini', 'Female', '2019-08-02 13:48:58', 'AIsha', 'Active'),
(5, 'Luul hasan Ali', 'Aisha', '8877691d24773f3cb0239ef411e35b71', 'hasdd@gmail.com', 'Wadajir', 'ddsdsdssf', 'Nurseimg/', '10', 'Male', '2019-08-02 13:37:32', 'AIsha', 'Active'),
(6, 'Hindi Abbas Ali', 'hindi123', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'hindi@hotmail.com', '061552233', 'Wadajir', 'Nurseimg/bannel.jpg', 'Sayid Ahmed', 'Female', '2019-09-18 17:38:35', 'AIsha', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `operations`
--

CREATE TABLE `operations` (
  `Id` int(11) NOT NULL,
  `O_Type` varchar(200) NOT NULL,
  `Rate` int(11) NOT NULL,
  `C_Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `operations`
--

INSERT INTO `operations` (`Id`, `O_Type`, `Rate`, `C_Date`, `User_name`) VALUES
(1, 'Cataract surgery', 780, '2019-08-02 17:54:40', '10'),
(2, 'Appendoctomy', 80, '2019-08-02 17:55:39', '10'),
(3, 'Breast biopsy', 100, '2019-08-02 17:56:21', '8'),
(4, 'Carotid endarterectomy', 100, '2019-08-02 17:56:59', '11'),
(5, 'Cesarean section', 20, '2019-08-02 17:57:46', '8'),
(6, 'Cholecystectomy', 55, '2019-08-02 17:59:23', '8'),
(7, 'Coronary artery bypass', 100, '2019-08-02 17:59:56', 'AIsha'),
(8, 'Debridement', 20, '2019-08-02 18:01:32', 'Aisha'),
(9, 'Dilation and curretage', 25, '2019-08-02 18:02:31', 'Aisha'),
(10, 'Skin graft', 50, '2019-08-02 18:03:15', 'Aisha'),
(11, 'Hemorrhoidectomy', 20, '2019-08-02 18:04:29', 'Aisha'),
(12, 'Hysterectomy', 50, '2019-08-02 18:05:28', 'Aisha'),
(13, 'Hysterectomy', 50, '2019-08-02 18:06:27', 'Aisha'),
(14, 'Hysteroscopy', 20, '2019-08-02 18:07:24', 'Aisha'),
(15, 'Inguinal hernia repair', 20, '2019-08-02 18:08:03', 'Aisha'),
(16, 'Low back pain surgery', 50, '2019-08-02 18:08:49', 'Aisha'),
(17, 'Mastectomy\r\n', 100, '2019-08-02 18:11:07', 'Aisha');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `Id` int(11) NOT NULL,
  `Fullname` varchar(70) NOT NULL,
  `Address` varchar(25) NOT NULL,
  `Tell` varchar(25) NOT NULL,
  `Age` varchar(10) NOT NULL,
  `Gender` varchar(15) NOT NULL,
  `Marital_Status` varchar(15) NOT NULL,
  `Ticket_id` int(11) NOT NULL,
  `Ticket_cost` int(11) NOT NULL,
  `Doctor_id` int(11) NOT NULL,
  `Doctor` varchar(100) NOT NULL,
  `Rate` double NOT NULL,
  `Patient_type` varchar(50) NOT NULL,
  `Creation_date` date NOT NULL,
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`Id`, `Fullname`, `Address`, `Tell`, `Age`, `Gender`, `Marital_Status`, `Ticket_id`, `Ticket_cost`, `Doctor_id`, `Doctor`, `Rate`, `Patient_type`, `Creation_date`, `User_name`) VALUES
(1, 'Sucdi Ali Moahamed', 'Wadajir', '061558888', '37-47', 'Female', 'Single', 5, 0, 20, 'Ummi', 20, 'OutPatient', '2019-08-03', 'AIsha'),
(2, 'Nurto Ali Hasan', 'Hodan', '061522333', '26-36', 'Female', 'Single', 2, 0, 12, 'Ahmed wali', 45, 'Inpatient', '2019-08-03', 'AIsha'),
(4, 'Ahmed Ali Ahmed', 'Waaberi', '06155887744', '<1', 'Male', 'Single', 2, 0, 13, 'dahir Hashi', 90, 'Inpatient', '2019-08-17', 'AIsha'),
(5, 'Abdirahman Hussein Ali', 'Hodan', '0615882200', '<1', 'Male', 'Single', 4, 0, 18, 'ali mohamed', 100, 'OutPatient', '2019-08-17', 'AIsha'),
(6, 'Mohamed Abdi Risak', 'Waaberi', '0615223351', '1-15', 'Male', 'Single', 5, 0, 21, 'Haji', 20, 'Inpatient', '2019-08-17', 'AIsha'),
(7, 'Maymun Ali Hasan', 'Dharkenley', '061552233', '26-36', 'Female', 'Single', 2, 0, 22, 'Luul Hasan Ali', 1, 'OutPatient', '2019-09-12', 'AIsha'),
(9, 'Said Ali Hassan', 'hodan', '0615223300', '16-25', 'Male', 'Single', 1, 10, 8, 'Sayid Ahmed', 1, 'OutPatient', '2019-09-18', 'AIsha'),
(10, 'Omar Aba Haji', 'waaberi', '0615522333', '16-25', 'Male', 'Single', 1, 10, 20, 'Ummi', 1, 'OutPatient', '2019-09-19', 'Ummi'),
(11, 'Yusro Mohamed  Ali', 'Dharkenley', '0615223322', '16-25', 'Female', 'Single', 2, 10, 20, 'Ummi', 1, 'OutPatient', '2019-09-19', 'AIsha'),
(12, 'abdiSHAKUR', 'WAABERI', '74747383', '16-25', 'Male', 'Single', 16, 10, 11, 'Geedi', 1, 'OutPatient', '2022-03-31', 'AIsha'),
(13, 'abdiSHAKUR', 'WAABERI', '888', '70-80', 'Male', 'Single', 7, 10, 1, 'Dhaqane Ali', 1, 'OutPatient', '2022-03-26', 'AIsha'),
(14, 'mohamed abdi salan', 'WAABERI', '6162358474', '16-25', 'Male', 'Single', 132, 10, 15, 'farah ali', 1, 'OutPatient', '2022-03-29', 'AIsha'),
(15, 'mohamed abdi', 'mogadishu/somal', '616237048', '16-25', 'Male', 'Single', 39, 10, 16, 'Sayidka ali', 1, 'Inpatient', '2022-04-10', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `patient_check_out`
--

CREATE TABLE `patient_check_out` (
  `Id` int(11) NOT NULL,
  `Patient_Id` int(11) NOT NULL,
  `Patient_Name` varchar(800) NOT NULL,
  `Room_no` int(11) NOT NULL,
  `Bed_no` varchar(130) NOT NULL,
  `Bed_cost` float NOT NULL,
  `Date_In` date NOT NULL,
  `Date_Out` date NOT NULL,
  `Days` int(11) NOT NULL,
  `Total_charge` float NOT NULL,
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient_check_out`
--

INSERT INTO `patient_check_out` (`Id`, `Patient_Id`, `Patient_Name`, `Room_no`, `Bed_no`, `Bed_cost`, `Date_In`, `Date_Out`, `Days`, `Total_charge`, `User_name`) VALUES
(12, 1, 'Ahmed Ali Ahmed', 5, 'B26', 50, '2019-08-03', '2019-08-19', 4, 4, 'AIsha'),
(13, 0, '', 0, '', 0, '0000-00-00', '2022-03-26', 0, 0, 'AIsha'),
(14, 0, '', 0, '', 0, '0000-00-00', '2022-03-26', 0, 0, 'AIsha'),
(15, 1, 'Mohamed Abdi Risak', 1, 'B8', 20, '2019-08-03', '2022-03-29', 924, 18480, 'AIsha'),
(16, 2, 'mohamed abdi', 6, 'B28', 0, '2019-08-03', '2022-04-10', 0, 0, 'AIsha');

--
-- Triggers `patient_check_out`
--
DELIMITER $$
CREATE TRIGGER `update_Staus_Active` BEFORE INSERT ON `patient_check_out` FOR EACH ROW UPDATE beds SET Status = 'Active' WHERE Bed_No = NEW.Bed_No
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `patient_diagnosis`
--

CREATE TABLE `patient_diagnosis` (
  `Id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Age` varchar(20) NOT NULL,
  `Gender` varchar(25) NOT NULL,
  `Patient_type` varchar(50) NOT NULL,
  `Doctor_name` varchar(50) NOT NULL,
  `Ticket_id` int(11) NOT NULL,
  `Problem` varchar(200) NOT NULL,
  `Diagnosis_date` date NOT NULL,
  `Diagnosis_name` varchar(25) NOT NULL,
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient_diagnosis`
--

INSERT INTO `patient_diagnosis` (`Id`, `Patient_id`, `Name`, `Age`, `Gender`, `Patient_type`, `Doctor_name`, `Ticket_id`, `Problem`, `Diagnosis_date`, `Diagnosis_name`, `User_name`) VALUES
(1, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '            waan bukaa                         ', '2019-08-04', 'Serology', 'AIsha'),
(2, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '            waan bukaa                         ', '2019-08-04', 'Stool', 'AIsha'),
(3, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', 'OutPatient', 'Ummi', 5, '    Qnadho oo galabtii marka laga gaaro aan is ku arko                                 ', '2019-08-04', 'Urine', 'AIsha'),
(4, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '                  waaa bukaan                   ', '2019-08-04', 'Urine', 'AIsha'),
(5, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '                  waaa bukaan                   ', '2019-08-04', 'Urine', 'AIsha'),
(6, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', 'OutPatient', 'Ummi', 5, '                       waa              ', '2019-08-05', 'Stool', 'AIsha'),
(7, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '                          waa            ', '2019-08-05', 'Hematology', 'AIsha'),
(8, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', 'OutPatient', 'Ummi', 5, '           waa                          ', '2019-08-05', 'Hematology', 'AIsha'),
(9, 4, 'Ahmed Ali Ahmed', '<1', 'Male', 'Inpatient', 'dahir Hashi', 2, '     waxaan ka cawanayaa qando                                ', '2019-08-17', 'Hematology', 'AIsha'),
(10, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', 'OutPatient', 'Ummi', 5, '         hergeb                            ', '2019-09-01', 'Urine', 'AIsha'),
(11, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', 'OutPatient', 'Ummi', 5, '                                     ', '2019-09-18', 'Malaria', 'AIsha'),
(12, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', 'OutPatient', 'Ummi', 5, '                                     ', '2019-09-18', 'Typhoid', 'AIsha'),
(13, 9, 'Said Ali Hassan', '16-25', 'Male', 'OutPatient', 'Sayid Ahmed', 1, 'gx                                     ', '2019-09-18', 'Malaria', 'AIsha'),
(14, 10, 'Omar Aba Haji', '16-25', 'Male', 'OutPatient', 'Ummi', 1, 'xanuun                                     ', '2019-09-19', 'Others', 'Ummi'),
(15, 11, 'Yusro Mohamed  Ali', '16-25', 'Female', 'OutPatient', 'Ummi', 2, '  madax                                    ', '2019-09-19', 'Malaria', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Cost` float NOT NULL,
  `Discount` float NOT NULL,
  `Payment_type` varchar(50) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `C_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Id`, `Name`, `Cost`, `Discount`, `Payment_type`, `Description`, `C_date`, `Username`) VALUES
(3, 'Maymun Ali Hasan', 1, 0, 'Evc-plus', 'jjkkjj', '2019-10-08 11:32:46', 'AIsha'),
(4, 'Sucdi Ali Moahamed', 1, 0, 'Cash', 'wuu bixiyey', '2019-10-08 11:32:46', 'AIsha'),
(5, 'Abdirahman Hussein Ali', 1, 0, 'Cash', 'nnjnj', '2019-10-08 11:32:46', 'AIsha'),
(6, 'Said Ali Hassan', 1, 0, 'Cash', 'jnjnk', '2019-10-08 11:32:46', 'AIsha'),
(7, 'Yusro Mohamed  Ali', 1, 0, 'Cash', 'jk', '2019-10-08 11:32:46', 'AIsha'),
(8, 'Yusro Mohamed  Ali', 1, 0, 'Cash', 'jk', '2019-10-08 11:32:46', 'AIsha'),
(9, 'Abdirahman Hussein Ali', 5.5, 2.5, 'Cash', 'Null', '2019-10-08 11:32:46', 'AIsha'),
(10, 'Abdirahman Hussein Ali', 5.5, 2.5, 'Cash', 'Null', '2019-10-08 11:32:46', 'AIsha'),
(11, 'Sucdi Ali Moahamed', 2, 0, 'Cash', 'waa', '0000-00-00 00:00:00', 'AIsha'),
(12, 'Abdirahman Hussein Ali', 1, 0, 'Cash', 'Null', '2019-10-08 10:42:23', 'AIsha'),
(13, 'Abdirahman Hussein Ali', 1, 0, 'Cash', 'Null', '0000-00-00 00:00:00', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE `permission` (
  `Id` int(11) NOT NULL,
  `Sidebar_id` int(11) NOT NULL,
  `User_id` int(11) NOT NULL,
  `C_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`Id`, `Sidebar_id`, `User_id`, `C_date`) VALUES
(1, 1, 8, '2019-08-27 10:42:51'),
(2, 54, 8, '2019-08-27 10:45:35'),
(3, 2, 8, '2019-08-27 10:46:07'),
(78, 7, 13, '2019-08-28 11:43:21'),
(79, 9, 13, '2019-08-28 11:43:23'),
(80, 12, 13, '2019-08-28 11:43:33'),
(81, 13, 13, '2019-08-28 11:43:35'),
(82, 31, 13, '2019-08-28 11:44:06'),
(83, 14, 13, '2019-08-28 11:46:22'),
(84, 15, 13, '2019-08-28 11:46:22'),
(85, 82, 8, '2019-08-31 08:44:58'),
(88, 84, 8, '2019-09-05 11:38:34'),
(92, 87, 13, '2019-09-09 17:33:00'),
(93, 14, 20, '2019-09-09 18:03:01'),
(95, 87, 20, '2019-09-09 18:03:03'),
(105, 13, 20, '2019-09-09 18:03:39'),
(107, 12, 20, '2019-09-09 18:03:44'),
(108, 88, 8, '2019-09-10 07:58:47'),
(109, 89, 8, '2019-09-10 08:20:54'),
(118, 79, 8, '2019-09-12 10:07:37'),
(125, 98, 8, '2019-09-18 07:03:06'),
(126, 15, 36, '2019-09-18 09:05:23'),
(127, 16, 36, '2019-09-18 09:05:24'),
(128, 17, 36, '2019-09-18 09:05:24'),
(129, 19, 36, '2019-09-18 09:05:24'),
(130, 18, 36, '2019-09-18 09:05:24'),
(131, 20, 36, '2019-09-18 09:05:24'),
(132, 21, 36, '2019-09-18 09:05:24'),
(133, 22, 36, '2019-09-18 09:05:24'),
(134, 23, 36, '2019-09-18 09:05:24'),
(135, 24, 36, '2019-09-18 09:05:24'),
(136, 25, 36, '2019-09-18 09:05:24'),
(137, 27, 36, '2019-09-18 09:05:24'),
(138, 26, 36, '2019-09-18 09:05:24'),
(149, 73, 36, '2019-09-18 09:05:30'),
(150, 74, 36, '2019-09-18 09:05:30'),
(152, 76, 36, '2019-09-18 09:05:30'),
(153, 77, 36, '2019-09-18 09:05:30'),
(154, 78, 36, '2019-09-18 09:05:30'),
(155, 28, 36, '2019-09-18 09:05:36'),
(156, 29, 36, '2019-09-18 09:05:37'),
(157, 3, 36, '2019-09-18 09:05:40'),
(158, 4, 36, '2019-09-18 09:05:40'),
(159, 5, 36, '2019-09-18 09:05:40'),
(160, 14, 36, '2019-09-18 09:05:40'),
(161, 97, 36, '2019-09-18 09:05:40'),
(162, 46, 36, '2019-09-18 09:05:41'),
(163, 45, 36, '2019-09-18 09:05:42'),
(164, 51, 8, '2019-09-18 09:07:48'),
(166, 52, 8, '2019-09-18 09:07:48'),
(167, 53, 8, '2019-09-18 09:07:50'),
(169, 47, 8, '2019-09-18 09:07:52'),
(170, 45, 8, '2019-09-18 09:07:54'),
(171, 46, 8, '2019-09-18 09:07:54'),
(173, 35, 8, '2019-09-18 09:07:56'),
(174, 34, 8, '2019-09-18 09:07:56'),
(175, 30, 8, '2019-09-18 09:07:56'),
(176, 31, 8, '2019-09-18 09:07:56'),
(177, 33, 8, '2019-09-18 09:07:56'),
(178, 32, 8, '2019-09-18 09:07:56'),
(179, 36, 8, '2019-09-18 09:07:56'),
(180, 37, 8, '2019-09-18 09:07:56'),
(181, 38, 8, '2019-09-18 09:07:56'),
(182, 39, 8, '2019-09-18 09:07:56'),
(183, 11, 8, '2019-09-18 09:07:58'),
(184, 10, 8, '2019-09-18 09:07:58'),
(185, 6, 8, '2019-09-18 09:07:58'),
(186, 7, 8, '2019-09-18 09:07:58'),
(187, 8, 8, '2019-09-18 09:07:58'),
(188, 9, 8, '2019-09-18 09:07:58'),
(189, 12, 8, '2019-09-18 09:07:58'),
(190, 13, 8, '2019-09-18 09:07:58'),
(191, 28, 8, '2019-09-18 09:08:00'),
(192, 29, 8, '2019-09-18 09:08:00'),
(193, 97, 8, '2019-09-18 09:08:02'),
(194, 3, 8, '2019-09-18 09:08:02'),
(195, 14, 8, '2019-09-18 09:08:02'),
(196, 4, 8, '2019-09-18 09:08:02'),
(197, 5, 8, '2019-09-18 09:08:02'),
(198, 17, 8, '2019-09-18 09:08:04'),
(199, 20, 8, '2019-09-18 09:08:04'),
(200, 16, 8, '2019-09-18 09:08:04'),
(201, 18, 8, '2019-09-18 09:08:04'),
(202, 19, 8, '2019-09-18 09:08:04'),
(203, 15, 8, '2019-09-18 09:08:04'),
(204, 21, 8, '2019-09-18 09:08:04'),
(205, 23, 8, '2019-09-18 09:08:04'),
(206, 22, 8, '2019-09-18 09:08:04'),
(207, 24, 8, '2019-09-18 09:08:04'),
(208, 25, 8, '2019-09-18 09:08:04'),
(209, 26, 8, '2019-09-18 09:08:04'),
(210, 27, 8, '2019-09-18 09:08:04'),
(211, 76, 8, '2019-09-18 09:08:05'),
(212, 75, 8, '2019-09-18 09:08:05'),
(213, 71, 8, '2019-09-18 09:08:05'),
(214, 72, 8, '2019-09-18 09:08:05'),
(215, 73, 8, '2019-09-18 09:08:05'),
(216, 74, 8, '2019-09-18 09:08:05'),
(217, 77, 8, '2019-09-18 09:08:05'),
(218, 78, 8, '2019-09-18 09:08:05'),
(219, 62, 8, '2019-09-18 09:08:08'),
(220, 61, 8, '2019-09-18 09:08:08'),
(221, 57, 8, '2019-09-18 09:08:08'),
(222, 58, 8, '2019-09-18 09:08:08'),
(223, 59, 8, '2019-09-18 09:08:08'),
(224, 60, 8, '2019-09-18 09:08:08'),
(225, 63, 8, '2019-09-18 09:08:08'),
(226, 65, 8, '2019-09-18 09:08:08'),
(227, 66, 8, '2019-09-18 09:08:08'),
(228, 64, 8, '2019-09-18 09:08:08'),
(229, 67, 8, '2019-09-18 09:08:08'),
(230, 68, 8, '2019-09-18 09:08:08'),
(231, 69, 8, '2019-09-18 09:08:08'),
(232, 83, 8, '2019-09-18 09:08:08'),
(233, 70, 8, '2019-09-18 09:08:08'),
(234, 85, 8, '2019-09-18 09:08:08'),
(235, 86, 8, '2019-09-18 09:08:08'),
(236, 92, 8, '2019-09-18 09:08:08'),
(237, 93, 8, '2019-09-18 09:08:08'),
(238, 94, 8, '2019-09-18 09:08:08'),
(239, 95, 8, '2019-09-18 09:08:09'),
(240, 96, 8, '2019-09-18 09:08:09'),
(241, 55, 8, '2019-09-18 09:08:10'),
(242, 56, 8, '2019-09-18 09:08:10'),
(243, 49, 8, '2019-09-18 09:08:11'),
(244, 50, 8, '2019-09-18 09:08:11'),
(245, 44, 8, '2019-09-18 09:08:13'),
(246, 43, 8, '2019-09-18 09:08:13'),
(247, 41, 8, '2019-09-18 09:08:13'),
(248, 42, 8, '2019-09-18 09:08:13'),
(249, 15, 45, '2019-09-18 19:05:24'),
(250, 16, 45, '2019-09-18 19:05:24'),
(251, 17, 45, '2019-09-18 19:05:24'),
(252, 19, 45, '2019-09-18 19:05:24'),
(253, 18, 45, '2019-09-18 19:05:24'),
(254, 20, 45, '2019-09-18 19:05:24'),
(255, 21, 45, '2019-09-18 19:05:24'),
(256, 22, 45, '2019-09-18 19:05:24'),
(257, 23, 45, '2019-09-18 19:05:24'),
(258, 24, 45, '2019-09-18 19:05:24'),
(259, 25, 45, '2019-09-18 19:05:24'),
(260, 26, 45, '2019-09-18 19:05:24'),
(261, 27, 45, '2019-09-18 19:05:24'),
(262, 82, 45, '2019-09-18 19:05:33'),
(263, 87, 46, '2019-09-19 08:48:51'),
(264, 14, 46, '2019-09-19 08:48:58'),
(266, 12, 46, '2019-09-19 08:49:22'),
(267, 13, 46, '2019-09-19 08:49:23'),
(268, 82, 46, '2019-09-19 08:49:33'),
(269, 87, 18, '2019-09-19 09:25:25'),
(270, 12, 18, '2019-09-19 09:25:30'),
(271, 13, 18, '2019-09-19 09:25:31'),
(272, 14, 18, '2019-09-19 09:25:40'),
(273, 82, 18, '2019-09-19 09:25:44'),
(274, 83, 18, '2019-09-19 09:25:46'),
(275, 64, 45, '2019-09-19 09:38:54'),
(276, 65, 45, '2019-09-19 09:38:55'),
(277, 66, 45, '2019-09-19 09:38:56'),
(278, 67, 45, '2019-09-19 09:38:57'),
(279, 68, 45, '2019-09-19 09:38:58'),
(280, 69, 45, '2019-09-19 09:38:59'),
(281, 92, 45, '2019-09-19 09:39:07'),
(282, 93, 45, '2019-09-19 09:39:07'),
(283, 94, 45, '2019-09-19 09:39:35'),
(284, 95, 45, '2019-09-19 09:39:58'),
(285, 96, 45, '2019-09-19 09:39:59'),
(320, 51, 48, '2019-09-19 09:58:18'),
(327, 52, 48, '2019-09-19 09:58:21'),
(335, 87, 48, '2019-09-19 09:58:21'),
(336, 99, 8, '2019-09-22 10:44:31'),
(337, 100, 8, '2019-10-08 11:29:02'),
(339, 48, 8, '2019-10-11 16:07:07'),
(340, 52, 14, '2022-03-21 09:18:01'),
(341, 87, 14, '2022-03-21 09:18:01'),
(342, 51, 14, '2022-03-21 09:18:01'),
(343, 53, 14, '2022-03-21 09:18:04'),
(344, 45, 14, '2022-03-21 09:18:06'),
(345, 46, 14, '2022-03-21 09:18:06'),
(346, 3, 14, '2022-03-21 09:18:07'),
(347, 4, 14, '2022-03-21 09:18:07'),
(348, 5, 14, '2022-03-21 09:18:07'),
(349, 14, 14, '2022-03-21 09:18:07'),
(350, 97, 14, '2022-03-21 09:18:07'),
(351, 48, 14, '2022-03-21 09:18:09'),
(352, 47, 14, '2022-03-21 09:18:09'),
(353, 79, 14, '2022-03-21 09:18:11'),
(354, 91, 14, '2022-03-21 09:18:11'),
(355, 31, 14, '2022-03-21 09:18:12'),
(356, 32, 14, '2022-03-21 09:18:12'),
(357, 33, 14, '2022-03-21 09:18:12'),
(358, 30, 14, '2022-03-21 09:18:12'),
(359, 34, 14, '2022-03-21 09:18:12'),
(360, 35, 14, '2022-03-21 09:18:12'),
(361, 36, 14, '2022-03-21 09:18:12'),
(362, 37, 14, '2022-03-21 09:18:12'),
(363, 38, 14, '2022-03-21 09:18:12'),
(364, 39, 14, '2022-03-21 09:18:12'),
(365, 6, 14, '2022-03-21 09:18:14'),
(366, 7, 14, '2022-03-21 09:18:14'),
(367, 9, 14, '2022-03-21 09:18:14'),
(368, 10, 14, '2022-03-21 09:18:14'),
(369, 11, 14, '2022-03-21 09:18:14'),
(370, 8, 14, '2022-03-21 09:18:14'),
(371, 12, 14, '2022-03-21 09:18:14'),
(372, 13, 14, '2022-03-21 09:18:14'),
(373, 28, 14, '2022-03-21 09:18:15'),
(374, 29, 14, '2022-03-21 09:18:15'),
(375, 15, 14, '2022-03-21 09:18:17'),
(376, 16, 14, '2022-03-21 09:18:17'),
(377, 17, 14, '2022-03-21 09:18:17'),
(378, 19, 14, '2022-03-21 09:18:17'),
(379, 20, 14, '2022-03-21 09:18:17'),
(380, 18, 14, '2022-03-21 09:18:17'),
(381, 25, 14, '2022-03-21 09:18:17'),
(382, 21, 14, '2022-03-21 09:18:17'),
(383, 24, 14, '2022-03-21 09:18:17'),
(384, 22, 14, '2022-03-21 09:18:17'),
(385, 23, 14, '2022-03-21 09:18:17'),
(386, 26, 14, '2022-03-21 09:18:17'),
(387, 27, 14, '2022-03-21 09:18:17'),
(388, 71, 14, '2022-03-21 09:18:19'),
(389, 72, 14, '2022-03-21 09:18:19'),
(390, 73, 14, '2022-03-21 09:18:19'),
(391, 74, 14, '2022-03-21 09:18:19'),
(392, 75, 14, '2022-03-21 09:18:19'),
(393, 76, 14, '2022-03-21 09:18:19'),
(394, 77, 14, '2022-03-21 09:18:19'),
(395, 78, 14, '2022-03-21 09:18:19'),
(396, 57, 14, '2022-03-21 09:18:23'),
(397, 59, 14, '2022-03-21 09:18:23'),
(398, 60, 14, '2022-03-21 09:18:23'),
(399, 61, 14, '2022-03-21 09:18:23'),
(400, 58, 14, '2022-03-21 09:18:23'),
(401, 62, 14, '2022-03-21 09:18:23'),
(402, 63, 14, '2022-03-21 09:18:23'),
(403, 64, 14, '2022-03-21 09:18:23'),
(404, 65, 14, '2022-03-21 09:18:23'),
(405, 66, 14, '2022-03-21 09:18:23'),
(406, 67, 14, '2022-03-21 09:18:23'),
(407, 68, 14, '2022-03-21 09:18:23'),
(408, 69, 14, '2022-03-21 09:18:23'),
(409, 70, 14, '2022-03-21 09:18:23'),
(410, 83, 14, '2022-03-21 09:18:23'),
(411, 85, 14, '2022-03-21 09:18:23'),
(412, 86, 14, '2022-03-21 09:18:23'),
(413, 92, 14, '2022-03-21 09:18:23'),
(414, 93, 14, '2022-03-21 09:18:23'),
(415, 94, 14, '2022-03-21 09:18:23'),
(416, 95, 14, '2022-03-21 09:18:23'),
(417, 96, 14, '2022-03-21 09:18:23'),
(418, 42, 14, '2022-03-21 09:18:25'),
(419, 41, 14, '2022-03-21 09:18:25'),
(420, 44, 14, '2022-03-21 09:18:25'),
(421, 43, 14, '2022-03-21 09:18:25'),
(422, 49, 14, '2022-03-21 09:18:28'),
(423, 50, 14, '2022-03-21 09:18:28'),
(424, 56, 14, '2022-03-21 09:18:29'),
(425, 99, 14, '2022-03-21 09:18:29'),
(426, 100, 14, '2022-03-21 09:18:29'),
(427, 55, 14, '2022-03-21 09:18:29'),
(428, 1, 14, '2022-03-21 09:18:31'),
(429, 2, 14, '2022-03-21 09:18:31'),
(430, 54, 14, '2022-03-21 09:18:32'),
(431, 82, 14, '2022-03-21 09:18:32'),
(432, 88, 14, '2022-03-21 09:18:32'),
(433, 89, 14, '2022-03-21 09:18:32'),
(434, 98, 14, '2022-03-21 09:18:32'),
(435, 84, 14, '2022-03-21 09:18:32'),
(504, 57, 50, '2022-03-29 08:06:08'),
(508, 61, 50, '2022-03-29 08:06:18'),
(516, 67, 50, '2022-03-29 08:06:22'),
(518, 68, 50, '2022-03-29 08:06:23'),
(520, 69, 50, '2022-03-29 08:06:25'),
(522, 70, 50, '2022-03-29 08:06:25'),
(524, 83, 50, '2022-03-29 08:06:31'),
(526, 85, 50, '2022-03-29 08:06:37'),
(530, 66, 50, '2022-03-29 08:09:51'),
(531, 65, 50, '2022-03-29 08:09:51'),
(532, 64, 50, '2022-03-29 08:09:52'),
(533, 87, 8, '2022-04-04 17:20:48'),
(534, 101, 8, '2022-04-04 17:21:03'),
(535, 102, 8, '2022-04-04 18:20:26'),
(536, 103, 8, '2022-04-04 18:32:22'),
(537, 101, 50, '2022-04-04 18:37:55'),
(538, 102, 50, '2022-04-04 18:37:56'),
(539, 103, 50, '2022-04-04 18:37:57');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

CREATE TABLE `pharmacist` (
  `Id` int(11) NOT NULL,
  `Fullname` varchar(200) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Picture` varchar(200) NOT NULL,
  `Mobile` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `C_Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Status` varchar(200) NOT NULL,
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pharmacist`
--

INSERT INTO `pharmacist` (`Id`, `Fullname`, `Username`, `Password`, `Email`, `Picture`, `Mobile`, `Gender`, `Address`, `C_Date`, `Status`, `User_name`) VALUES
(3, 'Nuuradin Ali Hasan', 'Nuradin12', '123', 'nuradini2022@gmail.com', 'Phimg/windows_xp_bliss.jpg', '0615522333', 'Female', 'Wadajir', '2019-09-06 17:54:37', 'Active', 'AIsha'),
(4, 'Zubeyr Ali Ahmed', 'Zubeyr44', '12345678', 'Zubeyr@gmail.com', 'Phimg/m1.png', '061552233', 'Male', 'hodan', '2019-09-18 17:55:25', 'InActive', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacytran`
--

CREATE TABLE `pharmacytran` (
  `Id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Patient_name` varchar(50) NOT NULL,
  `Ticket_id` int(11) NOT NULL,
  `Drug_name_id` int(11) NOT NULL,
  `Drug_name` varchar(25) NOT NULL,
  `Drug_type` varchar(50) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` double NOT NULL,
  `Discount` float NOT NULL,
  `Total` double NOT NULL,
  `Tran_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pharmacytran`
--

INSERT INTO `pharmacytran` (`Id`, `Patient_id`, `Patient_name`, `Ticket_id`, `Drug_name_id`, `Drug_name`, `Drug_type`, `Quantity`, `Price`, `Discount`, `Total`, `Tran_date`, `User_name`) VALUES
(1, 5, 'Abdirahman Hussein Ali', 4, 2, 'Syrup', 'Vitamin B complex', 2, 4, 3, 8, '2019-09-14 11:44:14', 'rr'),
(2, 2, 'Nurto Ali Hasan', 2, 2, 'Syrup', 'Vitamin B complex', 2, 3, 1, 6, '2019-08-09 07:46:49', 'AIsha'),
(3, 1, 'Sucdi Ali Moahamed', 5, 2, 'Syrup', 'Vitamin A complex', 9, 3, 0, 30, '2019-08-09 07:46:44', 'AIsha'),
(4, 1, 'Sucdi Ali Moahamed', 5, 1, 'Tablet', 'Coltab', 2, 3, 4, 6, '2019-08-14 08:07:53', 'AIsha'),
(5, 2, 'Nurto Ali Hasan', 2, 2, 'Syrup', 'Vitamin A complex', 4, 3, 1, 12, '2019-08-14 08:07:08', 'AIsha'),
(6, 1, 'Sucdi Ali Moahamed', 5, 1, 'Tablet', 'Coltab', 4, 2, 1, 8, '2019-08-14 08:07:31', 'AIsha'),
(7, 2, 'Nurto Ali Hasan', 2, 2, 'Syrup', 'Vitamin A complex', 2, 6, 1, 11, '2019-08-28 17:51:09', 'AIsha'),
(8, 3, 'Ruweyda Ali Hasan', 1, 2, 'Syrup', 'Vitamin B complex', 2, 4, 1, 7, '2019-09-14 11:58:11', 'AIsha'),
(9, 2, 'Nurto Ali Hasan', 2, 2, 'Syrup', 'Vitamin A complex', 4, 6, 1, 23, '2019-09-15 08:05:53', 'AIsha'),
(10, 5, 'Abdirahman Hussein Ali', 4, 1, 'Tablet', 'Coltab', 3, 1, 1, 2, '2019-09-18 18:36:37', 'AIsha'),
(11, 5, 'Abdirahman Hussein Ali', 4, 2, 'Syrup', 'Vitamin B complex', 2, 4, 0, 8, '2019-09-15 08:11:55', 'AIsha'),
(12, 3, 'Ruweyda Ali Hasan', 1, 2, 'Syrup', 'Vitamin B complex', 2, 4, 1, 7, '2019-09-15 08:15:05', 'AIsha'),
(13, 7, 'Maymun Ali Hasan', 2, 2, 'Syrup', 'Vitamin B complex', 2, 4, 1, 7, '2019-09-15 08:37:45', 'AIsha'),
(14, 3, 'Ruweyda Ali Hasan', 1, 2, 'Syrup', 'Vitamin B complex', 1, 4, 0, 4, '2019-09-15 08:43:23', 'AIsha'),
(15, 4, 'Ahmed Ali Ahmed', 2, 2, 'Syrup', 'Vitamin B complex', 2, 4, 0, 8, '2019-09-15 08:45:07', 'AIsha'),
(16, 4, 'Ahmed Ali Ahmed', 2, 2, 'Syrup', 'Vitamin B complex', 3, 4, 0, 12, '2019-09-15 08:48:22', 'AIsha'),
(17, 4, 'Ahmed Ali Ahmed', 2, 2, 'Syrup', 'Vitamin B complex', 48, 4, 0, 192, '2019-09-15 08:50:10', 'AIsha'),
(18, 4, 'Ahmed Ali Ahmed', 2, 2, 'Syrup', 'Vitamin A complex', 2, 6, 0, 12, '2019-09-15 08:53:12', 'AIsha'),
(19, 5, 'Abdirahman Hussein Ali', 4, 2, 'Syrup', 'Vitamin B complex', 4, 1, 1, 3, '2019-09-18 18:21:12', 'AIsha');

--
-- Triggers `pharmacytran`
--
DELIMITER $$
CREATE TRIGGER `updatequantity` AFTER INSERT ON `pharmacytran` FOR EACH ROW UPDATE drugs set Quantity=Quantity-NEW.Quantity where Drug_name=NEW.Drug_name
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `proggress_note`
--

CREATE TABLE `proggress_note` (
  `prid` int(11) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `rn` varchar(100) NOT NULL,
  `diagnosis` varchar(100) NOT NULL,
  `pdate` varchar(100) NOT NULL,
  `progressnote` varchar(500) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `result_laboratory`
--

CREATE TABLE `result_laboratory` (
  `Request_lab_id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Age` varchar(25) NOT NULL,
  `Gender` varchar(15) NOT NULL,
  `Diagnoses_name` varchar(50) NOT NULL,
  `Result` varchar(25) NOT NULL,
  `Test_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `result_laboratory`
--

INSERT INTO `result_laboratory` (`Request_lab_id`, `Name`, `Age`, `Gender`, `Diagnoses_name`, `Result`, `Test_date`) VALUES
(1, ' Abdifatah Ciilka', ' 16-25', ' Male          ', ' Malaria', 'Negative', '2019-07-21 08:11:00'),
(2, ' Saafi Ali Hasan', ' 10-20', ' Female        ', ' Typhoid', 'Positive', '2019-07-21 09:34:09'),
(3, ' Saafi Ali Hasan', ' 10-20', ' Female        ', ' Typhoid', 'Negative', '2019-07-21 09:34:31'),
(4, ' Abdifatah Ciilka', ' 16-25', ' Male          ', ' Blood_group', '14', '2019-07-21 09:34:44'),
(5, ' Abdifatah Ciilka', ' 16-25', ' Male          ', ' Blood_group', '5', '2019-07-21 09:34:59'),
(6, ' Abdifatah Ciilka', ' 16-25', ' Male          ', ' Malaria', 'Positive', '2019-07-21 09:35:28'),
(7, ' Filsan', ' <1', ' Female        ', ' Typhoid', 'Positive', '2019-07-21 09:36:01'),
(8, ' Filsan', ' <1', ' Female        ', ' Typhoid', 'Negative', '2019-07-21 09:36:15'),
(9, ' Cimran Nur Ali', ' 1-15', ' Male          ', ' Typhoid', 'Positive', '2019-07-21 09:37:06'),
(10, ' Cimran Nur Ali', ' 1-15', ' Male          ', ' Typhoid', 'Negative', '2019-07-21 09:37:24');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `Id` int(11) NOT NULL,
  `RoomNo` varchar(190) NOT NULL,
  `RoomType` varchar(20) NOT NULL,
  `No_Of_Beds` int(11) NOT NULL,
  `RoomCost` double NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `User_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`Id`, `RoomNo`, `RoomType`, `No_Of_Beds`, `RoomCost`, `Status`, `Creation_date`, `User_id`) VALUES
(1, '1', 'ACL', 6, 25, 'Active', '2019-07-17 10:22:29', 1),
(2, '2', 'Upnormal', 6, 25, 'Active', '2019-07-17 10:22:34', 1),
(3, '3', 'Normal', 5, 15, 'Inactive', '2019-07-17 10:22:37', 1),
(4, '4', 'Normal', 4, 15, 'Active', '2019-07-17 10:22:41', 1),
(5, '5', 'Normal', 5, 120, 'Active', '2019-07-17 10:22:46', 8),
(6, '6', 'no', 5, 20, 'Active', '2019-07-17 10:22:49', 1),
(7, '7', 'Upnormal', 3, 34, 'Active', '2019-07-17 10:31:58', 23),
(8, '10', 'Normal', 22, 5, 'Inactive', '2019-07-27 17:24:48', 8);

-- --------------------------------------------------------

--
-- Table structure for table `roomtype`
--

CREATE TABLE `roomtype` (
  `Id` int(11) NOT NULL,
  `Room_type` varchar(25) NOT NULL,
  `Beds` varchar(50) NOT NULL,
  `Creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `User_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roomtype`
--

INSERT INTO `roomtype` (`Id`, `Room_type`, `Beds`, `Creation_date`, `User_name`) VALUES
(1, 'Normal', '20', '2019-03-12 11:40:01', '1'),
(2, 'Upnormal', '60', '2019-03-17 10:16:35', '1'),
(3, 'ACR', '20', '2019-07-27 17:23:23', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `Id` int(11) NOT NULL,
  `Doctor_id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Available_days` varchar(300) NOT NULL,
  `Available_time` varchar(50) NOT NULL,
  `per_patient_time` varchar(50) NOT NULL,
  `Serial_visibility` varchar(50) NOT NULL,
  `Status` varchar(25) NOT NULL,
  `User_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`Id`, `Doctor_id`, `Name`, `Department`, `Available_days`, `Available_time`, `per_patient_time`, `Serial_visibility`, `Status`, `User_name`) VALUES
(1, 0, 'Ali', '', '7 weeks', '12:00-4:00', '30 min', 'Sequential', 'Active', 'Hasan'),
(2, 0, 'Sayid Ahmed', '', 'Saturday,Sunday', '200', '30', 'Timestamp', 'Active', 'ashi'),
(4, 0, 'Dhaqane Ali', '', 'Saturday,Sunday,Monday,Tuesday,Wednesday,Thursday', '12:00-4:00', '30 min', 'Timestamp', 'Inactive', 'AIsha'),
(5, 8, '', 'Asology', 'Saturday,Sunday', '12:00-4:00', '30', 'sequential', 'Active', 'AIsha'),
(6, 9, 'Ahmed Hashi', '17', 'Saturday,Sunday', '12:00-4:00', '30', 'sequential', 'Active', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `serology`
--

CREATE TABLE `serology` (
  `Request_lab_id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Age` varchar(25) NOT NULL,
  `Gender` varchar(25) NOT NULL,
  `Patient_type` varchar(50) NOT NULL,
  `Doctor_name` varchar(100) NOT NULL,
  `Ticketid` int(11) NOT NULL,
  `Test_date` date NOT NULL,
  `Widal_Test_AntigenH` varchar(25) NOT NULL,
  `Widal_Test_AntigenO` varchar(25) NOT NULL,
  `Brucela_Test_Abortus` varchar(25) NOT NULL,
  `Brucela_Test_Mentensis` varchar(25) NOT NULL,
  `VDRL` varchar(25) NOT NULL,
  `RPR` varchar(25) NOT NULL,
  `TPHA` varchar(25) NOT NULL,
  `ASO` varchar(25) NOT NULL,
  `CRP` varchar(25) NOT NULL,
  `HBsAg` varchar(25) NOT NULL,
  `HCV` varchar(25) NOT NULL,
  `RF` varchar(25) NOT NULL,
  `ToxoPlasmiasis` varchar(25) NOT NULL,
  `HelicobacterPylori` varchar(25) NOT NULL,
  `Prostate_Specific_Antigen` varchar(25) NOT NULL,
  `HIV` varchar(25) NOT NULL,
  `AAFBS` varchar(25) NOT NULL,
  `Others` varchar(25) NOT NULL,
  `User_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `serology`
--

INSERT INTO `serology` (`Request_lab_id`, `Patient_id`, `Name`, `Age`, `Gender`, `Patient_type`, `Doctor_name`, `Ticketid`, `Test_date`, `Widal_Test_AntigenH`, `Widal_Test_AntigenO`, `Brucela_Test_Abortus`, `Brucela_Test_Mentensis`, `VDRL`, `RPR`, `TPHA`, `ASO`, `CRP`, `HBsAg`, `HCV`, `RF`, `ToxoPlasmiasis`, `HelicobacterPylori`, `Prostate_Specific_Antigen`, `HIV`, `AAFBS`, `Others`, `User_name`) VALUES
(1, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '2019-08-05', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'AIsha'),
(2, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', 'OutPatient', 'Ummi', 5, '2019-08-15', 'normal', 'normal', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', 'AIsha'),
(3, 4, 'Ahmed Ali Ahmed', '<1', 'Male', 'Inpatient', 'dahir Hashi', 2, '2019-10-08', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', 'positive', '-----', 'no', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `sidebar`
--

CREATE TABLE `sidebar` (
  `Id` int(11) NOT NULL,
  `href` varchar(50) NOT NULL,
  `text` varchar(50) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `menu` varchar(50) NOT NULL,
  `C_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sidebar`
--

INSERT INTO `sidebar` (`Id`, `href`, `text`, `icon`, `menu`, `C_date`) VALUES
(1, 'users.php', 'Add user', 'fa fa-user-circle', 'User', '2019-08-18 16:10:41'),
(2, 'userlist.php', 'View user', 'fa fa-user-circle', 'User', '2019-08-26 10:54:05'),
(3, 'doctor_specialization.php', 'Doctor specialization', 'fa fa-user-md', 'Doctor', '2019-08-21 12:04:38'),
(4, 'adddoctor.php', 'Add Doctor', 'fa fa-user-md', 'Doctor', '2019-08-21 12:05:49'),
(5, 'doctor_lists.php', 'Doctor list', 'fa fa-user-md', 'Doctor', '2019-08-21 12:07:21'),
(6, 'addpatient.php', 'Add patient', 'fa fa-user', 'Patient', '2019-08-21 13:39:38'),
(7, 'pateint_list.php', 'Patient list', 'fa fa-user', 'Patient', '2019-08-21 13:41:25'),
(8, 'addinpatient.php', 'Add inpatient', 'fa fa-user', 'Patient', '2019-08-21 13:42:40'),
(9, 'inpatient_list.php', 'Inpatient list', 'fa fa-user', 'Patient', '2019-08-21 13:44:05'),
(10, 'Patient_Check_Out.php', 'Patient discharge', 'fa fa-user', 'Patient', '2019-08-21 13:46:15'),
(11, 'viewCheckout.php', 'Pat discharge list', 'fa fa-user', 'Patient', '2019-08-21 13:47:48'),
(12, 'treatment.php', 'Add treatment', 'fa fa-user', 'Patient', '2019-08-21 13:49:48'),
(13, 'treatment_list.php', 'Treatment list', 'fa fa-user', 'Patient', '2019-08-21 13:51:21'),
(14, 'add_patient_diagnosis.php', 'Add patient diagnosis', 'fa fa-user-md', 'Doctor', '2019-09-13 13:03:30'),
(15, 'pat_diagnosis_list_lab.php', 'Patient diagnosis list', 'fa fa-stethoscope', 'Laboratory', '2019-09-16 17:33:19'),
(16, 'addurine.php', 'Add urine', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:05:50'),
(17, 'urine_list.php', 'Urine list', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:06:37'),
(18, 'addstool_test.php', 'Add stool test', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:07:23'),
(19, 'stooltest_list.php', 'Stool test list', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:08:03'),
(20, 'addserology.php', 'Add serology', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:08:39'),
(21, 'serology_list.php', 'Serology list', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:09:25'),
(22, 'addhaematology.php', 'Add haematology', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:09:59'),
(23, 'haematology_list.php', 'Haematology list', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:10:35'),
(24, 'add_bio_chemestry.php', ' Add bio-chemestry', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:11:29'),
(25, 'biochemestry_list.php', 'Bio-chemestry list', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:12:14'),
(26, 'adddiagnosis.php', 'Add diagnosis', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:12:56'),
(27, 'diagnosis_list.php', 'Diagnosis_list', 'fa fa-stethoscope', 'Laboratory', '2019-08-21 16:13:33'),
(28, 'AddOperations.php', 'Add Operation', 'fa fa-circle-o', 'Operations', '2019-08-29 10:37:03'),
(29, 'OperationsList.php', 'Operation lists', 'fa fa-circle-o', 'Operations', '2019-08-29 10:37:11'),
(30, 'adddrugs.php', 'Add drugs', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:25:29'),
(31, 'drug_list.php', 'Drug list', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:25:20'),
(32, 'adddrug_group.php', 'Add druggroup', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:24:58'),
(33, 'druggroup_list.php', 'Druggroup list', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:25:45'),
(34, 'adddrug_type.php', 'Add drugtype', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:26:01'),
(35, 'drugtype_list.php', 'Drugtype list', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:26:07'),
(36, 'add_tablet_syrups.php', 'Add Tablet/syrups', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:26:13'),
(37, 'tablet_syrup_list.php', 'Tablet/syrups list', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:26:22'),
(38, 'adddisease.php', 'Add disease', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:26:45'),
(39, 'disease_list.php', 'Disease list', 'fa fa-eyedropper', 'Drugs', '2019-08-29 10:26:51'),
(41, 'addroomtype.php', 'Add roomtype', 'fa fa-home', 'Room Management', '2019-08-21 17:00:58'),
(42, 'addroom.php', 'Add room', 'fa fa-home', 'Room Management', '2019-08-21 17:03:06'),
(43, 'room_type_list.php', 'Roomtype list', 'fa fa-home', 'Room Management', '2019-08-21 17:04:04'),
(44, 'room_list.php', 'Room list', 'fa fa-home', 'Room Management', '2019-08-21 17:05:07'),
(45, 'Beds.php', 'Add Bed', 'fa fa-bed', 'Bed Management', '2019-08-21 17:07:04'),
(46, 'listbeds.php', 'Bed list', 'fa fa-bed', 'Bed Management', '2019-08-21 17:08:08'),
(47, 'adddepartment.php', 'Add Department', 'fa fa-sitemap', 'Department', '2019-08-21 17:09:27'),
(48, 'dept_list.php', 'Department list', 'fa fa-sitemap', 'Department', '2019-08-21 17:10:39'),
(49, 'addschedule.php', 'Add schedule', 'fa fa-list-alt', 'Schedule', '2019-08-21 17:11:35'),
(50, 'schedule_list.php', 'Schedule list', 'fa fa-list-alt', 'Schedule', '2019-08-21 17:12:33'),
(51, 'addappointment.php', 'Add appointment', 'fa fa-check-square-o', 'Appointment', '2019-08-21 17:14:20'),
(52, 'in_appoint_Admin_list.php', 'Appointment list admin', 'fa fa-check-square-o', 'Appointment', '2019-09-18 10:55:00'),
(53, 'system_backup.php', 'Add backup', 'fa fa-database', 'Backup', '2019-08-21 17:16:58'),
(54, 'form_permission.php', 'User permission', 'fa fa-user-secret', 'User management', '2019-08-29 10:38:35'),
(55, 'addpharmacytran.php', 'Pharmacy transaction', 'fa fa-money', 'Transaction', '2019-08-21 17:19:45'),
(56, 'pharm_tran_list.php', 'Ph_transaction list', 'fa fa-money', 'Transaction', '2019-08-21 17:21:01'),
(57, 'patient_report.php', 'Patient report 2 dates', 'fa fa-file-text', 'Report', '2019-08-21 17:22:41'),
(58, 'patient_rpt_appoint2date.php', 'Appointment report 2 dates', 'fa fa-file-text', 'Report', '2019-08-21 17:23:42'),
(59, 'patient_apppoint_rpt_status.php', 'Appointment report By Status', 'fa fa-file-text', 'Report', '2019-08-21 17:24:50'),
(60, 'doctors_rpt_address.php', 'Doctors report by address', 'fa fa-file-text', 'Report', '2019-08-21 17:25:57'),
(61, 'patient_rpt_address.php', 'Patient report by address', 'fa fa-file-text', 'Report', '2019-08-21 17:26:43'),
(62, 'emp_report_address.php', 'Employees report by address', 'fa fa-file-text', 'Report', '2019-08-21 17:27:34'),
(63, 'pharmacist_rpt_address.php', 'Pharmacist report by address', 'fa fa-file-text', 'Report', '2019-08-21 17:28:12'),
(64, 'patient_rpt_urine_diag.php', 'Patient report urine ', 'fa fa-file-text', 'Report', '2019-08-21 17:28:54'),
(65, 'patient_rpt_stool.php', 'Patient report stool', 'fa fa-file-text', 'Report', '2019-08-21 17:29:40'),
(66, 'patient_rpt_serology_diag.php', 'Patient report serology', 'fa fa-file-text', 'Report', '2019-08-21 17:30:24'),
(67, 'patient_rpt_biochem_diag.php', 'Patient report bio-chemtry', 'fa fa-file-text', 'Report', '2019-08-21 17:31:06'),
(68, 'patient_rpt_haematology.php', 'Patient report Haematlogy', 'fa fa-file-text', 'Report', '2019-08-21 17:31:50'),
(69, 'patient_rpt_malaria.php', 'Patient report malaria', 'fa fa-file-text', 'Report', '2019-08-21 17:32:33'),
(70, 'patient_rpt_chart_M_F.php', 'Patient chart', 'fa fa-file-text', 'Report', '2019-09-07 08:19:20'),
(71, 'addemployee.php', 'Add employee', 'fa fa-user-circle-o', 'Human Resources', '2019-08-21 17:34:57'),
(72, 'employee_list.php', 'Employee list', 'fa fa-user-circle-o', 'Human Resources', '2019-08-21 17:35:41'),
(73, 'addnurse.php', 'Add nurse', 'fa fa-user-circle-o', 'Human Resources', '2019-08-21 17:36:31'),
(74, 'nurse_list.php', 'Nurse list', 'fa fa-user-circle-o', 'Human Resources', '2019-08-21 17:37:18'),
(75, 'addpharmacist.php', 'Add pharmacist', 'fa fa-user-circle-o', 'Human Resources', '2019-08-21 17:38:17'),
(76, 'pharmacist_list.php', 'pharmacist list', 'fa fa-user-circle-o', 'Human Resources', '2019-08-21 17:39:09'),
(77, 'addlaboratorist.php', 'Add laboratorist', 'fa fa-user-circle-o', 'Human Resources', '2019-08-21 17:39:52'),
(78, 'laboratorist_list.php', 'Laboratorist list', 'fa fa-user-circle-o', 'Human Resources', '2019-08-21 17:40:27'),
(79, 'dashboard.php', 'Dashboard', 'fa fa-hospital-o', 'Dashboard', '2019-09-12 10:24:06'),
(82, 'change_password.php', 'Change password', 'fa fa-user-secret', 'User management', '2019-08-31 08:44:30'),
(83, 'patient_rpt_treatment.php', 'Treatment report', 'fa fa-file-text', 'Report', '2019-09-03 11:26:56'),
(84, 'reset_password.php', 'Reset password', 'fa fa-user-secret', 'User management', '2019-09-05 11:38:06'),
(85, 'inpatient_report_pu.php', 'Inpatient report paid/unpaid', 'fa fa-file-text', 'Report', '2019-09-08 08:22:44'),
(86, 'appointment_rpt_status_chart.php', 'Appointment status chart', 'fa fa-file-text', 'Report', '2019-09-09 07:45:33'),
(87, 'in_appoint_doc_list.php', 'Appointment lists doctor', 'fa fa-check-square-o', 'Appointment', '2019-09-18 10:54:32'),
(88, 'add_menu.php', 'Add menu', 'fa fa-user-secret', 'User management', '2019-09-10 07:58:29'),
(89, 'menu_list.php', 'Menu list', 'fa fa-archive', 'User management', '2019-09-10 08:20:43'),
(91, 'dashboard.php', 'Dashboard', 'fa fa-hospital-o', 'Dashboard', '2019-09-12 10:22:02'),
(92, 'All_report_urine.php', 'All urine reports', 'fa fa-file-text', 'Report', '2019-09-13 13:37:29'),
(93, 'All_report_stool.php', 'All stool report', 'fa fa-file-text', 'Report', '2019-09-13 14:39:31'),
(94, 'All_report_haematology.php', 'All haematology report', 'fa fa-file-text', 'Report', '2019-09-14 17:44:43'),
(95, 'All_report_serology.php', 'All serology report', 'fa fa-file-text', 'Report', '2019-09-14 17:44:58'),
(96, 'All_report_biochemestry.php', 'All biochemstry report', 'fa fa-file-text', 'Report', '2019-09-14 17:45:20'),
(97, 'patient_diagnosed_lists.php', 'Patient diagnoses lists', 'fa fa-user-md', 'Doctor', '2019-09-16 17:25:45'),
(98, 'ticket_cost_list.php', 'Ticket cost lists', 'fa fa-user-secret', 'User management', '2019-09-18 07:04:04'),
(99, 'addpayment.php', 'Add payment', 'fa fa-money', 'Transaction', '2019-09-22 10:42:02'),
(100, 'payment_list.php', 'Payments list', 'fa fa-money', 'Transaction', '2019-10-08 11:28:23'),
(101, 'intake.php', 'Patient Intake', 'fa fa-user', 'patient', '2022-04-04 17:19:20'),
(102, 'treatmentsheet.php', 'Patient Treatment', 'fa fa-user', 'patient', '2022-04-04 18:19:04'),
(103, 'progressnotes.php', 'Prgress Notes', 'fa fa-user', 'patient', '2022-04-04 18:31:58');

-- --------------------------------------------------------

--
-- Table structure for table `specialists`
--

CREATE TABLE `specialists` (
  `Id` int(11) NOT NULL,
  `Specialist_name` varchar(50) NOT NULL,
  `Creation_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `specialists`
--

INSERT INTO `specialists` (`Id`, `Specialist_name`, `Creation_date`) VALUES
(1, 'Neurology', '2019-01-01 16:02:08'),
(2, 'Ear,Nose,Throat(ENT)', '2019-01-01 16:02:52'),
(3, 'Eye', '2019-07-27 17:25:23');

-- --------------------------------------------------------

--
-- Table structure for table `stool_test`
--

CREATE TABLE `stool_test` (
  `Request_lab_id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Patient_name` varchar(50) NOT NULL,
  `Age` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Patient_type` varchar(50) NOT NULL,
  `Doctor_name` varchar(50) NOT NULL,
  `Ticket_id` int(11) NOT NULL,
  `Test_date` date NOT NULL,
  `E_Histolytic_vegetative` varchar(20) NOT NULL DEFAULT 'No',
  `Trichurus_ova` varchar(20) NOT NULL DEFAULT 'No',
  `E_coli_tropha_site` varchar(20) DEFAULT 'No',
  `E_varmecularis_ova` varchar(20) NOT NULL DEFAULT 'No',
  `Chilomasitx_mesnil` varchar(20) NOT NULL DEFAULT 'No',
  `Ascaris_ova` varchar(20) NOT NULL DEFAULT 'No',
  `Gidialamabia_troph` varchar(20) NOT NULL DEFAULT 'No',
  `Strongyloides_larvae_ova` varchar(20) NOT NULL DEFAULT 'No',
  `Trichomnas_homin` varchar(20) NOT NULL DEFAULT 'No',
  `G_lampia_cist` varchar(20) NOT NULL DEFAULT 'No',
  `E_histolytica_cysts` varchar(20) NOT NULL DEFAULT 'No',
  `Teania_saginate_ova` varchar(20) NOT NULL DEFAULT 'No',
  `E_coli_cysts` varchar(20) NOT NULL DEFAULT 'No',
  `Others` varchar(20) NOT NULL DEFAULT 'No',
  `User_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stool_test`
--

INSERT INTO `stool_test` (`Request_lab_id`, `Patient_id`, `Patient_name`, `Age`, `Gender`, `Patient_type`, `Doctor_name`, `Ticket_id`, `Test_date`, `E_Histolytic_vegetative`, `Trichurus_ova`, `E_coli_tropha_site`, `E_varmecularis_ova`, `Chilomasitx_mesnil`, `Ascaris_ova`, `Gidialamabia_troph`, `Strongyloides_larvae_ova`, `Trichomnas_homin`, `G_lampia_cist`, `E_histolytica_cysts`, `Teania_saginate_ova`, `E_coli_cysts`, `Others`, `User_name`) VALUES
(1, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', '', 'Ummi', 2, '2019-08-03', 'Yes', 'Yes', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'AIsha'),
(2, 1, 'Sucdi Ali Moahamed', '37-47', 'Female', '', 'Ummi', 2, '2019-08-03', 'No', 'Yes', 'Yes', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Yes', 'AIsha'),
(3, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '2019-08-05', 'Yes', 'Yes', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Yes', 'No', 'No', 'Yes', 'Yes', 'AIsha'),
(4, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '2019-08-05', 'Yes', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Yes', 'Yes', 'Yes', 'AIsha'),
(5, 6, 'Mohamed Abdi Risak', '1-15', 'Male', 'Inpatient', 'Haji', 5, '2019-08-14', 'Yes', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Yes', 'No', 'AIsha'),
(6, 4, 'Ahmed Ali Ahmed', '<1', 'Male', 'Inpatient', 'dahir Hashi', 2, '2019-10-08', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Yes', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `tablet_syrups`
--

CREATE TABLE `tablet_syrups` (
  `TS_id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tablet_syrups`
--

INSERT INTO `tablet_syrups` (`TS_id`, `Name`) VALUES
(1, 'Tablet'),
(2, 'Syrup');

-- --------------------------------------------------------

--
-- Table structure for table `ticketcost`
--

CREATE TABLE `ticketcost` (
  `Id` int(11) NOT NULL,
  `cost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ticketcost`
--

INSERT INTO `ticketcost` (`Id`, `cost`) VALUES
(1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `Treatment_id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Patient_name` varchar(50) NOT NULL,
  `Doctor_name` varchar(50) NOT NULL,
  `Ticket_id` int(11) NOT NULL,
  `Reg_date` date NOT NULL,
  `Drug` varchar(200) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Frequency_X` varchar(100) NOT NULL,
  `Duration` varchar(50) NOT NULL,
  `Route` text NOT NULL,
  `Stopped` varchar(10) NOT NULL,
  `Stopped_date` date NOT NULL,
  `Added_by` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`Treatment_id`, `Patient_id`, `Patient_name`, `Doctor_name`, `Ticket_id`, `Reg_date`, `Drug`, `Quantity`, `Frequency_X`, `Duration`, `Route`, `Stopped`, `Stopped_date`, `Added_by`) VALUES
(1, 1, 'Sucdi Ali Moahamed', 'Ummi', 5, '2019-08-14', 'tablet', 2, 'freqx', '3', '1 week', 'No', '0000-00-00', ''),
(3, 1, 'Sucdi Ali Moahamed', 'Ummi', 5, '2019-08-07', 'tablet', 1, '2', '3', '1 week', 'Yes', '2019-08-07', 'AIsha'),
(4, 2, 'Nurto Ali Hasan', 'Ahmed wali', 2, '2019-08-07', 'tablet', 2, '1', '4', '1 week', 'No', '0000-00-00', 'AIsha'),
(5, 1, 'Sucdi Ali Moahamed', 'Ummi', 5, '2019-08-07', 'tablet', 1, '0', '3', '1 week', 'Yes', '2019-08-07', 'AIsha'),
(10, 1, 'Sucdi Ali Moahamed', 'Ummi', 5, '2019-09-18', ' bracetemol', 5, '4', '5', 'mouth', 'Yes', '0000-00-00', 'AIsha'),
(11, 4, 'Ahmed Ali Ahmed', 'dahir Hashi', 2, '2019-09-18', ' as', 5, '3', '2', 'mouth', 'Yes', '0000-00-00', 'AIsha'),
(12, 2, 'Nurto Ali Hasan', 'Ahmed wali', 2, '2019-09-19', ' ', 5, '4', '7', 'mouth', 'Yes', '0000-00-00', 'AIsha'),
(13, 1, 'Sucdi Ali Moahamed', 'Ummi', 5, '2019-09-26', 'ncsnjn ', 5, '4', '7 days', 'mouth', 'Yes', '0000-00-00', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `urine`
--

CREATE TABLE `urine` (
  `Request_lab_id` int(11) NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Patient_name` varchar(50) NOT NULL,
  `Age` varchar(10) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Patient_type` varchar(50) NOT NULL,
  `Doctor_name` varchar(100) NOT NULL,
  `Ticket_id` int(11) NOT NULL,
  `Test_date` date NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Color` varchar(25) NOT NULL,
  `Appearance` varchar(25) NOT NULL,
  `Sediment` varchar(25) NOT NULL,
  `Albumin` varchar(25) NOT NULL,
  `Nitrin` varchar(15) NOT NULL,
  `Glucose` varchar(15) NOT NULL,
  `Protein` varchar(15) NOT NULL,
  `Birubin` varchar(15) NOT NULL,
  `Sangue` varchar(15) NOT NULL,
  `Uropil` varchar(15) NOT NULL,
  `Pregnancy` varchar(15) NOT NULL,
  `S_Graphity` varchar(15) NOT NULL,
  `Ph` varchar(15) NOT NULL,
  `Keton` varchar(15) NOT NULL,
  `WBC` varchar(25) NOT NULL,
  `RBC` varchar(25) NOT NULL,
  `EpithelialCells` varchar(25) NOT NULL,
  `Casis` varchar(25) NOT NULL,
  `Crystals` varchar(25) NOT NULL,
  `Others` varchar(15) NOT NULL,
  `User_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `urine`
--

INSERT INTO `urine` (`Request_lab_id`, `Patient_id`, `Patient_name`, `Age`, `Gender`, `Patient_type`, `Doctor_name`, `Ticket_id`, `Test_date`, `Quantity`, `Color`, `Appearance`, `Sediment`, `Albumin`, `Nitrin`, `Glucose`, `Protein`, `Birubin`, `Sangue`, `Uropil`, `Pregnancy`, `S_Graphity`, `Ph`, `Keton`, `WBC`, `RBC`, `EpithelialCells`, `Casis`, `Crystals`, `Others`, `User_name`) VALUES
(1, 2, 'Nurto Ali Hasan', '26-36', 'Female', 'Inpatient', 'Ahmed wali', 2, '2019-10-08', 5, 'yellow', 'dark green', 'sedi', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', 'AIsha');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Image` varchar(400) NOT NULL,
  `Tell` varchar(50) NOT NULL,
  `User_name` varchar(25) NOT NULL,
  `User_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Usertype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `Name`, `Username`, `Password`, `Email`, `Image`, `Tell`, `User_name`, `User_date`, `Usertype`) VALUES
(8, 'Aisha Hasan Ali', 'AIsha', '25d55ad283aa400af464c76d713c07ad', 'aisha@gmail.com', 'Img/d3.png', '0615223366', '7', '2022-03-26 07:23:57', 'Doctor'),
(9, 'Shadiyo Ali', 'Shadiyo', '8877691d24773f3cb0239ef411e35b71', 'Shad@gmail.com', 'img', '061552233', '1', '2019-03-19 17:52:18', 'Nurse'),
(11, 'Mohamed Abdi', 'Mohamed', '8877691d24773f3cb0239ef411e35b71', 'moha2@gmail.com', 'docupload', '2147483647', '8', '2019-03-25 07:14:05', 'Doctor'),
(13, 'Ismahn', 'Ismahanali', '8877691d24773f3cb0239ef411e35b71', 'Moha6@gmail.com', 'Docimg/d2.png', '2147483647', '8', '2019-03-25 07:25:40', 'Doctor'),
(14, 'Salim Ali', 'Salim', '25d55ad283aa400af464c76d713c07ad', 'maxamedyare236@gmail.com', 'Img/ju200363.jpg', '566565', '11', '2022-03-21 09:10:19', 'Admin'),
(15, 'Sayid Ahmed', 'sayid', '8877691d24773f3cb0239ef411e35b71', 'sayid@gmail.com', 'Docimg/ju200305.jpg', '2147483647', '11', '2019-03-25 07:51:55', 'Doctor'),
(16, 'sacdiyo Abbas Mahdi', 'sacdiyo', '8877691d24773f3cb0239ef411e35b71', 'sacdiyo@hotmail.com', 'Nurseimg/ju200301 (1).jpg', '02123232', '8', '2019-03-27 17:20:27', 'Nurse'),
(17, 'Xuseen carab', 'Xuseen', '8877691d24773f3cb0239ef411e35b71', 'xus@gmail.com', 'img', '2552255', '8', '2019-04-07 10:36:31', 'Labortorist'),
(18, 'Mohamed Ali Juha', 'Moha', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'mohaamed@gmail.com', 'Labimg/bannel.jpg', '5555', '8', '2019-09-19 09:28:52', 'Labortorist'),
(20, 'Ummi', 'Ummi', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'ummi@gmail.com', 'Docimg/d3.png', '56565655', '8', '2019-09-19 08:55:45', 'Doctor'),
(22, 'Faadumiini', 'fadumo', '8877691d24773f3cb0239ef411e35b71', 'fad12@gmail.com', 'Docimg/d3.png', '111616161', '8', '2019-04-16 14:33:36', 'Doctor'),
(23, 'Mahdi Anwar Abbas', 'Mahdi', 'f89a8fcbfaa2b6a0bbe6a88eb519b742', 'mahdi@gmail.com', 'Img/user2-160x160.png', '5151515', '0', '2019-09-05 11:39:55', 'User'),
(24, 'Yusuf Anwar Hasan', 'Yuusuf11', '8877691d24773f3cb0239ef411e35b71', 'yusufa@mail.com', 'Img/m4.png', '5655955656', 'AIsha', '2019-09-18 19:08:34', 'User'),
(25, 'Zair Ali Hasan', 'Zair12', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'Zair@gmail.com', 'Img/bannel.jpg', '0615522333', 'AIsha', '2019-08-27 09:34:29', 'User'),
(28, 'Yaska Nur Ali', 'yaska12', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'yas77@gmail.com', 'Img/bannel.jpg', '061558899', 'AIsha', '2019-08-27 09:38:13', 'User'),
(29, 'Zakiye Ali Hasan', 'Zakiya12', '72f7ed01db47bf7f3fa04abd150e102e', 'zakiya@gmail.com', 'Img/bannel.jpg', '061559988', 'AIsha', '2019-08-27 09:41:02', 'User'),
(34, 'Fardowso Qadafi Ali', 'fardoso12', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'fard@gmail.com', 'Img/1.jpg', '0615223368', 'AIsha', '2019-08-31 11:00:51', 'User'),
(37, 'Qalid Ali Hasan', 'qalid123', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'qalid@gmail.com', 'Docimg/bannel.jpg', '61555555', '8', '2019-09-06 14:27:50', 'Doctor'),
(38, 'Hadi Ali Hasan', 'Hadi144', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'hadi@gmail.com', 'picture', '06155223366', '0', '2019-09-06 17:38:14', 'Pharmacist'),
(40, 'Nuuradin Ali Hasan', 'Nuradin12', '8877691d24773f3cb0239ef411e35b71', 'nuradini2022@gmail.com', 'Phimg/windows_xp_bliss.jpg', '0615522333', 'AIsha', '2019-09-06 17:54:37', 'Pharmacist'),
(42, 'Yasir Ali Mohamed', 'yasir12', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'yasir@gmail.com', 'Docimg/bannel.jpg', '615522336', '8', '2019-09-18 17:23:54', 'Doctor'),
(43, 'Hindi Abbas Ali', 'hindi123', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'hindi@hotmail.com', 'Nurseimg/bannel.jpg', 'Wadajir', 'AIsha', '2019-09-18 17:38:35', 'Nurse'),
(44, 'Zubeyr Ali Ahmed', 'Zubeyr44', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'Zubeyr@gmail.com', 'Phimg/m1.png', '061552233', 'AIsha', '2019-09-18 17:53:50', 'Pharmacist'),
(45, 'Fahad Abbas Ali', 'fahad12', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'fahad@gmsil.com', 'Labimg/d2.png', '061552233', 'AIsha', '2019-09-18 18:02:08', 'Labortorist'),
(46, 'Feysal Ali Ahmed', 'feysal', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'feysal@gmail.com', 'Docimg/d2.png', '615223366', '8', '2019-09-19 08:47:26', 'Doctor'),
(47, 'Abukar Nur Ali', 'Abukar', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'Abukar33@gmail.com', 'Img/m3.png', '061552233', 'AIsha', '2019-09-19 09:46:01', 'User'),
(49, 'Bashiir Nur Ali', 'bashiir', 'df5225b59acf7ef0de0ad27f9e3ea0bd', 'bashiir@gmail.com', 'Img/m3.png', '0615224477', 'AIsha', '2019-09-19 10:02:14', 'User'),
(50, 'mohamed abdi salan', 'tika', '25d55ad283aa400af464c76d713c07ad', 'tika@gmail.com', 'Img/9780134852553.jpg', '616237048', 'AIsha', '2022-03-29 08:03:52', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `userType` int(11) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `Phone`, `address`, `username`, `userType`, `password`, `image`, `user_id`, `date`) VALUES
(1, 'dr salma mohamed ali', '615445522', 'shirkole', 'salma', 1, '1212', 'fgfdjgfsd.png', 1, '2022-04-12 14:05:49');

-- --------------------------------------------------------

--
-- Table structure for table `user_send_code`
--

CREATE TABLE `user_send_code` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `code` int(11) NOT NULL,
  `C_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_send_code`
--

INSERT INTO `user_send_code` (`id`, `email`, `code`, `C_date`) VALUES
(1, 'hh@gmail.com', 1001, '2019-09-07 12:11:36'),
(2, 'hh@gmail.com', 1002, '2019-09-07 12:20:16'),
(3, 'hh@gmail.com', 1004, '2019-09-07 12:30:37'),
(4, 'hh@gmail.com', 1007, '2019-09-07 12:31:27'),
(5, 'hh@gmail.com', 1011, '2019-09-08 18:14:13'),
(6, 'hh@gmail.com', 1016, '2019-09-09 10:46:42'),
(7, 'hh@gmail.com', 1022, '2019-09-09 10:47:37'),
(8, 'hh@gmail.com', 1029, '2019-09-09 10:49:08'),
(9, 'hh@gmail.com', 1037, '2019-09-09 10:49:17'),
(10, 'hh@gmail.com', 1046, '2019-09-10 11:51:56'),
(11, 'hh@gmail.com', 1056, '2019-09-14 08:59:34'),
(12, 'hh@gmail.com', 1067, '2019-09-14 09:00:39'),
(13, 'hh@gmail.com', 1079, '2019-09-14 09:01:39'),
(14, 'hh@gmail.com', 1092, '2019-09-14 09:01:48'),
(15, 'hh@gmail.com', 1106, '2019-09-14 09:17:30'),
(16, 'hh@gmail.com', 1121, '2019-09-14 09:18:02'),
(17, 'hh@gmail.com', 1137, '2019-09-14 09:18:38'),
(18, 'hh@gmail.com', 1154, '2019-09-14 09:20:12'),
(19, 'hh@gmail.com', 1172, '2019-09-18 08:13:26'),
(20, 'maxamedyare236@gmail.com', 1191, '2022-03-21 09:08:00'),
(21, 'aisha@gmail.com', 1211, '2022-03-21 09:14:54'),
(22, 'aisha@gmail.com', 1232, '2022-03-26 07:22:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `assigningdoc`
--
ALTER TABLE `assigningdoc`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `beds`
--
ALTER TABLE `beds`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `bio_chemestry`
--
ALTER TABLE `bio_chemestry`
  ADD PRIMARY KEY (`Request_lab_id`);

--
-- Indexes for table `blood_test`
--
ALTER TABLE `blood_test`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`Cityid`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`Deptid`);

--
-- Indexes for table `diagnosis`
--
ALTER TABLE `diagnosis`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `disease`
--
ALTER TABLE `disease`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `doc_email` (`Email`);

--
-- Indexes for table `druggroup`
--
ALTER TABLE `druggroup`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `drugs`
--
ALTER TABLE `drugs`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `drugtype`
--
ALTER TABLE `drugtype`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `haematology`
--
ALTER TABLE `haematology`
  ADD PRIMARY KEY (`Request_lab_id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `intake`
--
ALTER TABLE `intake`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `in_appointment`
--
ALTER TABLE `in_appointment`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `in_patient`
--
ALTER TABLE `in_patient`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `laboratoristreg`
--
ALTER TABLE `laboratoristreg`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `nurses`
--
ALTER TABLE `nurses`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `operations`
--
ALTER TABLE `operations`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `patient_check_out`
--
ALTER TABLE `patient_check_out`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `patient_diagnosis`
--
ALTER TABLE `patient_diagnosis`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `permission`
--
ALTER TABLE `permission`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Sidebar_id` (`Sidebar_id`,`User_id`);

--
-- Indexes for table `pharmacist`
--
ALTER TABLE `pharmacist`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `pharmacytran`
--
ALTER TABLE `pharmacytran`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `proggress_note`
--
ALTER TABLE `proggress_note`
  ADD PRIMARY KEY (`prid`);

--
-- Indexes for table `result_laboratory`
--
ALTER TABLE `result_laboratory`
  ADD PRIMARY KEY (`Request_lab_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `roomtype`
--
ALTER TABLE `roomtype`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `serology`
--
ALTER TABLE `serology`
  ADD PRIMARY KEY (`Request_lab_id`);

--
-- Indexes for table `sidebar`
--
ALTER TABLE `sidebar`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `specialists`
--
ALTER TABLE `specialists`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `stool_test`
--
ALTER TABLE `stool_test`
  ADD PRIMARY KEY (`Request_lab_id`);

--
-- Indexes for table `ticketcost`
--
ALTER TABLE `ticketcost`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `treatment`
--
ALTER TABLE `treatment`
  ADD PRIMARY KEY (`Treatment_id`);

--
-- Indexes for table `urine`
--
ALTER TABLE `urine`
  ADD PRIMARY KEY (`Request_lab_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_send_code`
--
ALTER TABLE `user_send_code`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `assigningdoc`
--
ALTER TABLE `assigningdoc`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `beds`
--
ALTER TABLE `beds`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `bio_chemestry`
--
ALTER TABLE `bio_chemestry`
  MODIFY `Request_lab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `blood_test`
--
ALTER TABLE `blood_test`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `Cityid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `Deptid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `diagnosis`
--
ALTER TABLE `diagnosis`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `disease`
--
ALTER TABLE `disease`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `druggroup`
--
ALTER TABLE `druggroup`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `drugs`
--
ALTER TABLE `drugs`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `drugtype`
--
ALTER TABLE `drugtype`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `haematology`
--
ALTER TABLE `haematology`
  MODIFY `Request_lab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `intake`
--
ALTER TABLE `intake`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `in_appointment`
--
ALTER TABLE `in_appointment`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `in_patient`
--
ALTER TABLE `in_patient`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `laboratoristreg`
--
ALTER TABLE `laboratoristreg`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `nurses`
--
ALTER TABLE `nurses`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `operations`
--
ALTER TABLE `operations`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `patient_check_out`
--
ALTER TABLE `patient_check_out`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `patient_diagnosis`
--
ALTER TABLE `patient_diagnosis`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `permission`
--
ALTER TABLE `permission`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=540;

--
-- AUTO_INCREMENT for table `pharmacist`
--
ALTER TABLE `pharmacist`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pharmacytran`
--
ALTER TABLE `pharmacytran`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `proggress_note`
--
ALTER TABLE `proggress_note`
  MODIFY `prid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `result_laboratory`
--
ALTER TABLE `result_laboratory`
  MODIFY `Request_lab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `roomtype`
--
ALTER TABLE `roomtype`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `serology`
--
ALTER TABLE `serology`
  MODIFY `Request_lab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sidebar`
--
ALTER TABLE `sidebar`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `specialists`
--
ALTER TABLE `specialists`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stool_test`
--
ALTER TABLE `stool_test`
  MODIFY `Request_lab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ticketcost`
--
ALTER TABLE `ticketcost`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `treatment`
--
ALTER TABLE `treatment`
  MODIFY `Treatment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `urine`
--
ALTER TABLE `urine`
  MODIFY `Request_lab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_send_code`
--
ALTER TABLE `user_send_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
